<!doctype html>
<html lang="en">
 <?php include_once ('template/head.php')?>
<!--<form>-->
	<body>
		<?php include_once('template/header.php');?>
		<br/>
			<div class="container">
				<div class="row">
					<div class=" col-sm-8" style="border-top: 0px;">
						<div class="row">
							<div class="col-sm-12">
								<br/>
									<div class="card">
										<div class="card-header" style="background: #F0F0F0;">
											<center><h5>GENERAL DEDUCTIONS</h5></center>
										</div>
											<div class="card-body">
												<center><h5 class="card-title">LOAN DEDUCTIONS </h5></center>
												<div class="form-group">
													<label for="exampleFormControlSelect1">Category Name</label>
														<select class="form-control" id="exampleFormControlSelect1">
															<option selected>--Select--</option>
															<option>Food</option>
															<option>Phones</option>
															<option>Electronis</option>
															<option>Houses</option>
															<option>Money</option>
															<option>Others</option>
														</select>
												</div>
			
												<div class="form-group">
													<label for="exampleFormControlSelect1">Product Name</label>
														<select class="form-control" id="exampleFormControlSelect1">
															<option selected>--Select--</option>
															<option>Rice</option>
															<option>White Rice</option>
															<option>Semovita</option>
															<option>Milo</option>
															<option>Peak Powder</option>
															<option>Peak Liquid</option>
															<option>Maggi</option>
															<option>Rayco</option>
															<option>Ovaltine</option>
															<option>Milo</option>
															<option>Cous-Cous</option>
															<option>Maccaroni</option>
															<option>Indomie</option>
															<option>Luna Liquid</option>
															<option>Suger</option>
															<option>Plour</option>
															<option>Oki Oil (25ltr)</option>
															<option>Oki Oil (5ltr)</option>
															<option>Mobile Phone</option>
															<option>Lapto Computer</option>
														</select>
												</div>
											
												<div class="card">
													<div class="card-body">
														<h5><center>DEDUCTIONS REPORT</center></h5>
														<table class="table table-bordered table-striped">
															<tr>
																<th>Membership ID</th>
																<th>Name</th>
																<th>Department</th>
																<th>Amount</th>
																<th> </th>
															</tr>
															<tr>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td> </td>
															</tr>
															<tr>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td> </td>
															</tr>
															<tr>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td> </td>
															</tr>
															<tr>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td> </td>
															</tr>
															<tr>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td> </td>
															</tr>
															<tr>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td> </td>
															</tr>
															
														</table>
													</div>
												</div>	
											</div>
									</div>
							</div>
									<div class="col-sm-12" >
										<div class="card" style="min-height: 400px; margin: 0px;">
											<div class="card-body">
												<center><h5 class="card-title">LIST OF BANK TRANSACTIONS</h5></center>
													<table class="table table-bordered table-striped">
														<tr>
															<th>Bank Name</th>
															<th>Account No.</th>
															<th>Transaction</th>
															<th>ID</th>
															<th>Amount</th>
															<th>Date</th>
														</tr>
														<tr>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
														</tr>
														<tr>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
														</tr>
														<tr>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
														</tr>
														<tr>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
														</tr>
														<tr>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
														</tr>
														<tr>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
															<td>Data</td>
														</tr>
														
													</table>
											</div>
										</div>
									</div>
									
						</div>
					</div>
					<?php include_once('template/menu.php');?>
				</div>
			</div>
<!--</form>-->
		<footer class="footer mt-auto py-3"  style="background: #F0F0F0;">
			<div class="container">
				<center><p class="text-muted">Copyright &copy; 2020: All Rights</p></center>
			</div>
		</footer>
	</body>
</html>