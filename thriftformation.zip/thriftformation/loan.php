<!doctype html>
<html lang="en">
<?php include_once ('template/head.php')?>
<!--<form>-->
	<body>
		<?php include_once('template/header.php');?>
		<br/>
			<div class="container">
				<div class="row">
					<div class="col-sm-9">
						<div class="btn-group" role="group" aria-label="Basic example" style="margin-bottom: 10px;">
						  <a href="#" class="btn btn-primary">Loan List</a> &nbsp;&nbsp;
						  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ApplyLoanModal">Apply Loan</button>
						  
						</div>

							<div class="card">
                <div class="card-header">
                   <center><h5>LIST OF MEMBERS WHO RECIEVED CASH LOAN</h5></center>
                </div>
                <div class="card-body">
                  <table class="table table-bordered table-responsive" id="tbl_loan" style="font-size:14px;">
                <thead>
                <!-- <tr>
                  <th colspan="8" align="center">Loan Information</th>
                </tr> -->
                <tr>
                  <td><strong>S/N</strong></td>
                  <td style="width:150px;"><strong>Name</strong></td>
                  <td><strong>Amount Recieved</strong></td>
                  <td><strong>Date Recieved</strong></td>
                  <td><strong>Rem. Balance</strong></td>
                  <td><strong>Loan Payment</strong></td>
                  <!-- <td><strong>Action</strong></td> -->
                  
                </tr>
                </thead>
                <tbody id="loadloans">

                </tbody>
              </table>
                </div>
              </div>
					</div>
						<?php include_once('template/menu.php');?>
				</div>
			</div>
<!--</form>-->
<?php include_once('template/footer.php');?>
<?php include_once('modals/loans/apply_loan.php')?>
<?php include_once('modals/loans/pay_loan.php')?>

<?php include_once('scripts/javascript.php')?>
<script src="js/bootstrap-select.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $('.selectpicker').selectpicker();
  })
</script>
<script type="text/javascript">
	 $("#ApplyLoanModal").modal({
        show: false,
        backdrop: 'static'
    });  
  $("#PayLoanModal").modal({
        show: false,
        backdrop: 'static'
    });
</script>
<script type="text/javascript">
	 //this function is usded in getting list of loan application
   function loadLoanList() {
    setInterval(function(){
           var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
           document.getElementById("loadloans").innerHTML = this.responseText;
          }
        };
        xhttp.open("GET", "Loanlist.php", true);
        xhttp.send();
      },1000);
    }
    loadLoanList();
</script>
<script type="text/javascript">
	 $('#loandata').on("submit", function(event){  
           event.preventDefault();  
           if($('#selectpicker').val() == "")  
           {  
               
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Please select member name');
           } 
           else if($('#loan_amount').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Pleaes enter loan amount'); 
           } 
           else if($('#loan_request_date').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Please select request date'); 
           } 
           else if($('#years').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Please select loan period'); 
           } 
           else if($('#interest').val() == '')
           {  
                //alert("Phone number is required"); 
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Please enter loan interest');  
           }
           else  
           {  
                $.ajax({  
                     url:"app/loan/insert.php",  
                     method:"POST",  
                     data:$('#loandata').serialize(),  
                     beforeSend:function(){  
                          $('#btnLoan').val("Saving Loan...");  
                     },  
                     success:function(data){ 
                          alertify.set('notifier','position', 'top-right');
                          alertify.success('Loan Aplication Successful'); 
                          $('#loandata')[0].reset();
                          $('#btnLoan').val("Save");  
                          //$('#ApplyLoanModal').modal('hide');  
                          //$('#member_table').html(data);  
                     }  
                });  
           }  
      });

      $(document).on('click', '.pay_myloan', function(){  
           var member_id = $(this).attr("id");  
           $.ajax({  
                url:"app/loan/fetch.php",  
                method:"POST",  
                data:{member_id:member_id},  
                dataType:"json",  
                success:function(data){  
                     $('#date_collected').html(data.date_collected);  
                     $('#amt_recieved').html(data.amt);  
                     $('#interest_on_loan').html(data.interest);  
                     $('#expeced_interest').val(data.exp_interest);  
                     $('#exp_paybackamt').val(data.exp_amt);  
                     //$('#loan_balance').html(data.balance);    
                     $('#member_name').val(data.member_id);  
                     $('#loan_interest_amt').html(data.exp_interest);   
                     $('#member_id').html(data.id);  
                     $('#btnPayLoan').val("Pay Loan");  
                     $('.pay-loan-modal').modal('show');  
                }  
           });  
      });

      $('#LoanPaymentForm').on("submit", function(event){  
           event.preventDefault();  
           if($('#amt_paid').val() == "")  
           {  
               
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Enter amount recieved');
           } 
           else  
           {  
                $.ajax({  
                     url:"app/loan/payloan.php",  
                     method:"POST",   
                     data:{
                        member_name:$('#member_name').val(),
                        new_balance:$('#new_balance').val()
                      }, 
                      cache: false, 
                     beforeSend:function(){  
                          $('#btnPayLoan').val("Paying Loan...");  
                     },  
                     success:function(data){  
                          alertify.set('notifier','position', 'top-right');
                          alertify.success('Payment recieved');
                          $('#LoanPaymentForm')[0].reset();
                          $('#btnPayLoan').val("Pay Loan"); 
                     }  
                });  
           }  
      }); 
      $('#tbl_loan').DataTable();
</script>
</body>
