  <?php
function formatMoney($number, $fractional=false) {
    if ($fractional) {
        $number = sprintf('%.2f', $number);
    }
    while (true) {
        $replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
        if ($replaced != $number) {
            $number = $replaced;
        } else {
            break;
        }
    }
    return $number;
}

    if(isset($_POST['btnSearch'])){
    $outputTotal = '';
    $a=$_POST['from'];
    $b=$_POST['to'];
    include_once('../../connection.php');
    $result1 = mysqli_query($connect,"SELECT sum(amount) as total_contributions FROM deposit where date_deposit BETWEEN '$a' AND '$b'");
    $row = mysqli_fetch_array($result1);
    echo json_encode($row); 
    // while($row = mysqli_fetch_array($result1))
    // {
    //   $outputTotal=$row['total_contributions'];
    //   echo "&#8358;".formatMoney($outputTotal, true);
    //  }
    //  echo "&#8358;".formatMoney($outputTotal, true);
    }
  ?>