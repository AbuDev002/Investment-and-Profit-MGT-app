 <?php 
 session_start(); 
 include_once('../../connection.php');
 function formatMoney($number, $fractional=false) {
    if ($fractional) {
        $number = sprintf('%.2f', $number);
    }
    while (true) {
        $replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
        if ($replaced != $number) {
            $number = $replaced;
        } else {
            break;
        }
    }
    return $number;
}   
 if(!empty($_POST))  
 {  
      $i = 0;
      $output = '';  
      $message = '';  
      $user_id = mysqli_real_escape_string($connect, $_POST["member_id"]);  
      $amount = mysqli_real_escape_string($connect, $_POST["amount"]);  
      $date_deposit = mysqli_real_escape_string($connect, $_POST["date_deposit"]);  
      
      //this query is used to get name of members
      $get_member_name = mysqli_query($connect,"select * from members where id=".$user_id."");
        $get_member_name_rs = mysqli_fetch_array($get_member_name);
        $member_name = $get_member_name_rs['surname']." ".$get_member_name_rs['firstname']." ".$get_member_name_rs['othername'];
      $query = "  
           INSERT INTO deposit (users_id,amount,date_deposit)  
           VALUES('".$user_id."','$amount', '$date_deposit');";
           $track_qr = mysqli_query($connect,"INSERT INTO activity_tracker (activity_descrip,user_id) VALUES('Inputed monthly contribution recieved from $member_name','".$_SESSION['userid']."')");  
           $message = '<p class="text text-success">Added Successfully</p>';  
      
      if(mysqli_query($connect, $query))  
      {  
           $output .= '<label class="text-success">' . $message . '</label>';  
           $select_query = "SELECT * FROM deposit ORDER BY id DESC";  
           $result = mysqli_query($connect, $select_query);  
           $output .= '
                <div id="contribution_table">   
                <table class="table table-bordered table-striped table-responsive contribution_list" id="contribution_table">   
                     <thead>
                         <tr>
                            <th>S/N</th>
                            <th>Name of Member</th>
                            <th>Amount Contributed</th>
                            <th>Date Contributed</th>
                          </tr>
                        </thead>
                    <tbody> 
           ';  
           while($row = mysqli_fetch_array($result))  
           {  
              $getusername = mysqli_query($connect,"select * from members where id='".$row["users_id"]."'");
                $name = mysqli_fetch_array($getusername);
           		$i++;
                $output .= '  
                     <tr>  
                          <td>' .$i. '</td>  
                          <td>' . $name["surname"] . ' '.$name["firstname"].' '.$name["othername"].'</td>  
                          <td>' . "&#8358; ".formatMoney($row["amount"], true). '</td>  
                          <td>' . $row["date_deposit"] . '</td>  
                           
                           
                     </tr>  
                ';  
           }  
           $output .= '</tbody> </table></div>';  
      }  
      echo $output;  
 }  
 ?>