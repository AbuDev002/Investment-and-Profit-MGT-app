<?php 
  include_once('../../connection.php');
  if(isset($_POST["date_deposit"])){
    $result = mysqli_query($connect,"SELECT sum(amount) as monthTotal FROM deposit WHERE date_deposit = '".$_POST["date_deposit"]."'");
    $array = mysqli_fetch_array($result);   
    echo json_encode($array);
}
?>