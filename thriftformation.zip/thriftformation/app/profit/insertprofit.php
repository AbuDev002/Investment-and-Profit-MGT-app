<?php
session_start();
include_once('../../connection.php');
if (isset($_POST['members_contribution']) AND isset($_POST['contribution_month']) AND isset($_POST['profit_obtained'])) {
    $members_contribution = $_POST['members_contribution'];
    $contribution_month = $_POST['contribution_month'];
    $profit_obtained = $_POST['profit_obtained'];
    //select month from database and update if month exist;
    $checkmonth = mysqli_query($connect,"SELECT * FROM profit WHERE profit_month='".$contribution_month."'");
    if($monthexist = mysqli_num_rows($checkmonth) >0){
        $updateprofit = mysqli_query($connect,"UPDATE profit SET profit_amount='".$profit_obtained."', members_contrubution_amount='".$members_contribution."' WHERE profit_month='".$contribution_month."'");
        if($updateprofit){
            //track profit sharing
            $track_qr = mysqli_query($connect,"INSERT INTO activity_tracker (activity_descrip,user_id) VALUES('Shared profit for the month of $contribution_month','".$_SESSION['userid']."')");  
        echo "ok";
        }else{
            echo "fail";
        }
    }else{
    $addprofit = mysqli_query($connect, "INSERT INTO profit(members_contrubution_amount,profit_month,profit_amount) VALUES ('$members_contribution','$contribution_month','$profit_obtained')");
    if($addprofit){
        //track profit sharing
        $track_qr = mysqli_query($connect,"INSERT INTO activity_tracker (activity_descrip,user_id) VALUES('Shared profit for the month of $contribution_month','".$_SESSION['userid']."')");
    	echo "ok";
    }else{
    	echo "fail";
    }
    }
   }
?>