 <?php  
 session_start();
 include_once('../../connection.php');   
 if(!empty($_POST))  
 {  
      $output = '';  
      $message = '';  
      $staff_id = mysqli_real_escape_string($connect, $_POST["staff_id"]);  
      $loan_amount = mysqli_real_escape_string($connect, $_POST["loan_amount"]);  
      $loan_request_date = mysqli_real_escape_string($connect, $_POST["loan_request_date"]);   
      $years = mysqli_real_escape_string($connect, $_POST["years"]);  
      $interest = mysqli_real_escape_string($connect, $_POST["interest"]);  
      $monthly_payment = mysqli_real_escape_string($connect, $_POST["monthly_payment"]);   
      $paytotal = mysqli_real_escape_string($connect, $_POST["paytotal"]);  
      $totalinterest = mysqli_real_escape_string($connect, $_POST["totalinterest"]);

      //this query is used to get name of members
      $get_member_name = mysqli_query($connect,"select * from members where id=".$staff_id."");
        $get_member_name_rs = mysqli_fetch_array($get_member_name);
        $member_name = $get_member_name_rs['surname']." ".$get_member_name_rs['firstname']." ".$get_member_name_rs['othername'];
      if($_POST["member_id"] != '')  
      {  
           $query = "  
           UPDATE loan   
           SET 
           date_collected='$loan_request_date',   
           amt='$loan_amount',
           interest='$interest',
           exp_interest = '$totalinterest',   
           member_id=".$staff_id.",
           exp_amt = '$paytotal',    
           loan_duration='$years',   
           balance = '$loan_amount'      
           WHERE id=".$_POST["member_id"]."";   
           $message = '<div class="alert alert-success">Loan Record Updated</div>';  
      }  
      else  
      {  
           
           $query = "INSERT INTO loan (`date_collected`, `amt`, `interest`, `exp_interest`, `member_id`, `exp_amt`, `loan_duration`, `balance`) VALUES ('$loan_request_date', '$loan_amount', '$interest','$totalinterest', ".$staff_id.", '$paytotal', '$years', '$loan_amount')";  
        $track_qr = mysqli_query($connect,"INSERT INTO activity_tracker (activity_descrip,user_id) VALUES('Issued a loan to $member_name','".$_SESSION['userid']."')"); 
      }  
      if(mysqli_query($connect, $query))  
      {  
           $message = 'Loan Recorded Successfully'; 
      }  
 }  
 ?>