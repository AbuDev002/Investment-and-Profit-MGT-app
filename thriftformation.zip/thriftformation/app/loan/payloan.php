 <?php 
 session_start(); 
 include_once('../../connection.php');   
 if(!empty($_POST))  
 {    
      //$message = '';
      $loan_status = 0;  
      $member_id = mysqli_real_escape_string($connect, $_POST["member_name"]);  
      $new_balance = mysqli_real_escape_string($connect, $_POST["new_balance"]);    
      if($member_id != '')  
      { 
      //this query is used to get name of members
      $get_member_name = mysqli_query($connect,"select * from members where id=".$member_id."");
        $get_member_name_rs = mysqli_fetch_array($get_member_name);
        $member_name = $get_member_name_rs['surname']." ".$get_member_name_rs['firstname']." ".$get_member_name_rs['othername'];
         if($new_balance == 0){
           $loan_status = 1;
         }else{
           $loan_status =0;
         }
       $query = mysqli_query($connect,"UPDATE loan SET exp_amt = '".$new_balance."',loan_status = '".$loan_status."' WHERE member_id=".$member_id."");
       $track_qr = mysqli_query($connect,"INSERT INTO activity_tracker (activity_descrip,user_id) VALUES('Recieved a loan repayment from $member_name and balance remains $new_balance','".$_SESSION['userid']."')");
        
     } 
      echo "ok"; 
 }  
 ?>