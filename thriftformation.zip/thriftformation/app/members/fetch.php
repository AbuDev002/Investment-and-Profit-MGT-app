 <?php  
 //fetch.php  
include_once('../../connection.php');  
 if(isset($_POST["member_id"]))  
 {  
      $query = "SELECT * FROM members WHERE id = ".$_POST["member_id"]."";  
      $result = mysqli_query($connect, $query);  
      $row = mysqli_fetch_array($result);  
      echo json_encode($row);  
 }  
 ?>