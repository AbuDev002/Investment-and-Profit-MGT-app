 <?php 
 session_start(); 
 include_once('../../connection.php');   
 if(!empty($_POST))  
 {  
      $output = '';  
      $message = '';  
      $staffno = mysqli_real_escape_string($connect, $_POST["staffno"]);  
      $firstname = mysqli_real_escape_string($connect, $_POST["firstname"]);  
      $surname = mysqli_real_escape_string($connect, $_POST["surname"]);  
      $othername = mysqli_real_escape_string($connect, $_POST["othername"]);  
      $gender = mysqli_real_escape_string($connect, $_POST["gender"]);  
      $marital_status = mysqli_real_escape_string($connect, $_POST["marital_status"]);  
      $phoneno = mysqli_real_escape_string($connect, $_POST["phoneno"]);   
      $address = mysqli_real_escape_string($connect, $_POST["address"]);  
      $nok_name = mysqli_real_escape_string($connect, $_POST["nok_name"]);  
      $nok_relationship = mysqli_real_escape_string($connect, $_POST["nok_relationship"]);  
      $nok_address = mysqli_real_escape_string($connect, $_POST["nok_address"]);  
      if($_POST["member_id"] != '')  
      {  
           $query = "  
           UPDATE members   
           SET 
           staffno='$staffno',   
           firstname='$firstname',   
           surname='$surname',   
           othername='$othername',   
           gender='$gender',   
           marital_status='$marital_status',   
           phoneno = '$phoneno',     
           address = '$address',   
           nok_name = '$nok_name',   
           nok_relationship = '$nok_relationship',   
           nok_address = '$nok_address'    
           WHERE id=".$_POST["member_id"]."";
            $track_qr = mysqli_query($connect,"INSERT INTO activity_tracker (activity_descrip,user_id) VALUES('Updated $firstname $surname $othername details in the system','".$_SESSION['userid']."')");   
           $message = '<div class="alert alert-success">Member Data Updated</div>';  
      }  
      else  
      {  
           $query = "  
           INSERT INTO members (staffno,firstname, surname, othername, gender, marital_status,phoneno,address,nok_name,nok_relationship,nok_address)  
           VALUES('$staffno','$firstname', '$surname', '$othername', '$gender', '$marital_status', '$phoneno', '$address', '$nok_name', '$nok_relationship', '$nok_address');  
           ";
           $track_qr = mysqli_query($connect,"INSERT INTO activity_tracker (activity_descrip,user_id) VALUES('Added $firstname $surname $othername to the system','".$_SESSION['userid']."')");  
           $message = 'New Member Added Successfully';  
      }  
      if(mysqli_query($connect, $query))  
      {  
           $output .= '<label class="text-success">' . $message . '</label>';  
           $select_query = "SELECT * FROM members ORDER BY id DESC";  
           $result = mysqli_query($connect, $select_query);  
           $output .= '
                <div id="member_table">   
                <table class="table table-bordered table-striped table-responsive members_list">   
                     <thead>
                          <tr>
                          <th>Staff No.</th>
                          <th>Name</th>
                          <th></th>
                          <th></th>
                        </tr>
                        </thead>
                    <tbody> 
           ';  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '  
                     <tr>  
                          <td>' . $row["staffno"] . '</td>  
                          <td>' . $row["surname"] . ' '.$row["firstname"].' '.$row["othername"].'</td>  
                          <td><input type="button" name="edit" value="Edit" id="'.$row["id"] .'" class="btn btn-info btn-xs edit_data" /></td>  
                          <td><input type="button" name="view" value="view" id="' . $row["id"] . '" class="btn btn-info btn-xs view_data" /></td>  
                     </tr>  
                ';  
           }  
           $output .= '</tbody> </table></div>';  
      }  
      echo $output;  
 }  
 ?>