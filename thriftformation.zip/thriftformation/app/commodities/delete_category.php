 <?php  
 //fetch.php  
include_once('../../connection.php');  
 if(isset($_POST["member_id"]))  
 {  
      $query = "DELETE FROM product_category WHERE id = ".$_POST["member_id"]."";  
      $result = mysqli_query($connect, $query);  
      if($result){
      echo "ok";  
      }
 }  
 ?>