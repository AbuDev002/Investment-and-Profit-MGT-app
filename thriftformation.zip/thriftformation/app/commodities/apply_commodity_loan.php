 <?php
 session_start();  
 include_once('../../connection.php');   
 if(!empty($_POST))  
 {  
      $output = '';  
      $message = '';  
      $member_name = mysqli_real_escape_string($connect, $_POST["member_name"]);
      $product_name = mysqli_real_escape_string($connect, $_POST["product_name"]);
      $product_price = mysqli_real_escape_string($connect, $_POST["product_price"]);
      $date_recieved = mysqli_real_escape_string($connect, $_POST["date_recieved"]);
      $loan_charges = mysqli_real_escape_string($connect, $_POST["loan_charges"]);
      $loan_duration = mysqli_real_escape_string($connect, $_POST["loan_duration"]);

      //this query is used to get name of members
      $get_member_name = mysqli_query($connect,"select * from members where id=".$member_name."");
        $get_member_name_rs = mysqli_fetch_array($get_member_name);
        $member_name_id = $get_member_name_rs['surname']." ".$get_member_name_rs['firstname']." ".$get_member_name_rs['othername'];

     $query = "INSERT INTO commodities_loan (`member_id`,`product_id`,`product_price`,`date_recieved`,`percent_charges`,`loan_duration`) VALUES ('$member_name','$product_name','$product_price','$date_recieved','$loan_charges','$loan_duration')";    
      if(mysqli_query($connect, $query))  
      {  
          $track_qr = mysqli_query($connect,"INSERT INTO activity_tracker (activity_descrip,user_id) VALUES('Issued commodity loan to $member_name_id at $loan_charges','".$_SESSION['userid']."')"); 
           $message = 'ok'; 
      }  
 }  
 ?>