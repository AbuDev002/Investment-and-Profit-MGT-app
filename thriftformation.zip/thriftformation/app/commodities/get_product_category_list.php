<?php  
      $output = '';  
      include_once('../../connection.php');  
      $query = "SELECT * FROM product_category ORDER BY id DESC LIMIT 5";  
      $result = mysqli_query($connect, $query);  
      
      while($row = mysqli_fetch_array($result))  
      {
      ?>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            <?php echo $row['category_name']?>
            <button class="btn btn-danger delete_category" id="<?php echo $row['id'];?>"><span class="badge badge-danger badge-pill"><i class="fa fa-trash"></i></span></button>
          </li> 
     <?php } ?>