<?php  
      $output = '';  
      include_once('../../connection.php');  
      $query = "SELECT * FROM products ORDER BY id DESC LIMIT 5";  
      $result = mysqli_query($connect, $query);  
      
      while($row = mysqli_fetch_array($result))  
      {
      ?>
          <tr>
            <td><?php echo $row['product_name']?></td>
            <td><?php echo $row['unit_price']?></td>
            <td><?php 
             $get_cat = mysqli_query($connect,"select * from product_category where id='".$row['category_id']."'");
               $catrs = mysqli_fetch_array($get_cat);
               echo $catrs['category_name']; 
            ?></td>
            <td>
              <button class="btn btn-danger delete_product" id="<?php echo $row['id'];?>"><span class="badge badge-danger badge-pill"><i class="fa fa-trash"></i></span></button>
            </td>
          </tr> 
     <?php } ?>