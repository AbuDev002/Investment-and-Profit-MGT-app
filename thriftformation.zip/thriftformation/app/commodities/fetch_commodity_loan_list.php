 <?php    
include_once('../../connection.php');  
  if(isset($_POST["member_id"]))  
 {  
      $query = "SELECT * FROM commodities_loan WHERE id= ".$_POST["member_id"]."";  
      $result = mysqli_query($connect, $query);  
      while($row = mysqli_fetch_array($result)){
      		//get product name
      		$get_product_name = mysqli_query($connect,"select * from products where id=".$row["product_id"]."");
      		   	$get_product_name_rs = mysqli_fetch_array($get_product_name);
      				//get member fullname
      		   		$get_member_name = mysqli_query($connect,"select * from members where id =".$row["member_id"]."");
      		   			$get_member_name_rs = mysqli_fetch_array($get_member_name);
      echo '<table class="table table-bordered">
      			<tr>
      				<td colspan="2" align="center"><h5>'.$get_member_name_rs["surname"].' '.$get_member_name_rs["firstname"].' '.$get_member_name_rs["othername"].'</h5></td>
      			</tr>
                        <input type="hidden" name="member_name" value="'.$row["member_id"].'" id="member_name">
      			<tr>
      				<td><strong>Product Name</strong></td>
      				<td>'.$get_product_name_rs["product_name"].'</td>
      			</tr>
      			<tr>
      				<td><strong>Product Price</strong></td>
      				<td>'.$row["product_price"].'</td>
      			</tr>
      			<tr>
      				<td><strong>Date Recieved</strong></td>
      				<td>'.$row["date_recieved"].'</td>
      			</tr>
      			<tr>
      				<td><strong>Remaing Bal.</strong></td>
      				<td>'.$row["percent_charges"].'</td>
      				<input type="hidden" id="rembalance" value="'.$row["percent_charges"].'">
      			</tr>
      			<tr>
      				<td><strong>Duration (Month)</strong></td>
      				<td>'.$row["loan_duration"].'</td>
      			</tr>
      </table>';
} }?>