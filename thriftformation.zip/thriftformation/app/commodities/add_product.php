 <?php
 session_start();  
 include_once('../../connection.php');   
 if(!empty($_POST))  
 {  
      $output = '';  
      $message = '';  
      $product_name = mysqli_real_escape_string($connect, $_POST["product_name"]);
      $product_price = mysqli_real_escape_string($connect, $_POST["product_price"]);
      $product_category = mysqli_real_escape_string($connect, $_POST["product_category"]);
     $query = "INSERT INTO products (`product_name`,`unit_price`,`category_id`) VALUES ('$product_name','$product_price','$product_category')";    
      if(mysqli_query($connect, $query))  
      {  
        $track_qr = mysqli_query($connect,"INSERT INTO activity_tracker (activity_descrip,user_id) VALUES('Added new product in commodities','".$_SESSION['userid']."')"); 
           $message = 'ok'; 
      }  
 }  
 ?>