 <?php 
 session_start(); 
 include_once('../../connection.php');   
 if(!empty($_POST))  
 {    
      //$message = ''; 
      $loan_status = 0; 
      $member_id = mysqli_real_escape_string($connect, $_POST["member_name"]);  
      $remaining_balance = mysqli_real_escape_string($connect, $_POST["remaining_balance"]); 

       //this query is used to get name of members
      $get_member_name = mysqli_query($connect,"select * from members where id=".$member_id."");
        $get_member_name_rs = mysqli_fetch_array($get_member_name);
        $member_name_id = $get_member_name_rs['surname']." ".$get_member_name_rs['firstname']." ".$get_member_name_rs['othername'];   
      if($member_id != '')  
      {  

      if($remaining_balance == 0){
           $loan_status = 1;
         }else{
           $loan_status =0;
         }
       $query = mysqli_query($connect,"UPDATE commodities_loan SET percent_charges = '".$remaining_balance."',loan_status = '".$loan_status."' WHERE member_id=".$member_id."");
       $track_qr = mysqli_query($connect,"INSERT INTO activity_tracker (activity_descrip,user_id) VALUES('Recieved commodity loan repayment from $member_name_id and balance remains $remaining_balance','".$_SESSION['userid']."')");
        
     } 
      echo "ok"; 
 }  
 ?>