 <?php
 session_start();  
 include_once('../../connection.php');   
 if(!empty($_POST))  
 {  
      $output = '';  
      $message = '';  
      $category_name = mysqli_real_escape_string($connect, $_POST["category_name"]);
     $query = "INSERT INTO product_category (`category_name`) VALUES ('$category_name')";    
      if(mysqli_query($connect, $query))  
      {  
      	$track_qr = mysqli_query($connect,"INSERT INTO activity_tracker (activity_descrip,user_id) VALUES('Added new category of product in commodities','".$_SESSION['userid']."')");  
           $message = 'ok'; 
      }  
 }  
 ?>