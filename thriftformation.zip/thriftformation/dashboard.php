<?php
	session_start();
	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
			header('location:index.php');
	}
?>

<!doctype html>
<html lang="en">
  <?php include_once ('template/head.php')?>
  <body>
<?php include_once('template/header.php');?>
<div class="container">
  <br/>
  <div class="row">
    <div class="col-md-9">
		<div class="row">
			<div class="col-sm-12">
				<div class="card">
					<div class="card-body">
						<div class="jumbotron jumbotron-fluid">
							<div class="container">
								<h3 class="">Bauchi State Hada kai Cooperative Society</h3>
								<p class="lead">Investment and Profit Management Software</p>
							</div>
						</div>
					</div>
					<fieldset class="scheduler-border" style="border:1px none !important;">
						<legend class="scheduler-border">Recent Activities</legend>
						<table class="table table-bordered" id="recent_activity" style="font-size: 14px;">
							<thead>
							<tr>
								<th>User</th>
								<th>Description of activity</th>
								<th>Date</th>
							</tr>
							</thead>
							<tbody>
							<?php
								include_once('connection.php');
								$get_all_activities = mysqli_query($connect,"select * from activity_tracker order by id desc");
								while($activity_rs = mysqli_fetch_array($get_all_activities)){
							?>
							
							<tr>
								<td>
									<?php 
									 $get_user_name = mysqli_query($connect,"select * from adminusers where userid=".$activity_rs['user_id']."");
									  $get_user_name_rs = mysqli_fetch_array($get_user_name);
									  echo $get_user_name_rs['name']
									?>
										
								</td>
								<td><?php echo $activity_rs['activity_descrip']?></td>
								<td><?php echo $activity_rs['activity_date']?></td>
							</tr>
						    <?php } ?>
						    </tbody>
						</table>
					</fieldset>
				</div>
			</div>
		</div>
	</div>
		<?php include_once('template/menu.php');?>
	
  </div>
</div>
	<?php include_once('template/footer.php');?>
	<?php include_once('scripts/javascript.php');?>
	<script type="text/javascript">
		$('#recent_activity').DataTable({
			pageLength : 5,
    		lengthMenu: [[5, 10, 20, -1], [5, 10, 20, 'Todos']]
		});
	</script>
</body> 
</html>