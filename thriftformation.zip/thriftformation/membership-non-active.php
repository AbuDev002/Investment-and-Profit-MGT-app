<?php
  session_start();
  if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
      header('location:index.php');
  }
?>
 <?php 
 $i = 0; 
 include_once('connection.php'); 
 $query = "SELECT * FROM members WHERE status= 1 ORDER BY id DESC";  
 $result = mysqli_query($connect, $query);  
 ?>  
<!doctype html>
<html lang="en">
 <?php include_once ('template/head.php')?>
<body>
 
	<?php include_once('template/header.php');?>
	<br/>
		<div class="container">
			<div class="row">
				<div class="col-md-9" style= "borde-top: 0px;">
					<div class="row">
						<div class="col-sm-12">
							<br/>						
								<div class="card">
									<div class="card-header">
										<!-- <center><h5>LIST OF MEMBERS</h5></center> -->
									</div>
									<div class="container" style="padding: 0px;">
										<div class="row">
											<div class="col-md-12">
												<div class="card">
													<div class="card-body">
								<ul class="nav">
                  <li class="nav-item">
                    <a class="nav-link active" href="membership-active.php">Active Members</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="membership-non-active.php">Non Active Members</a>
                  </li>
                </ul>
                              <ul class="nav justify-content-end">
                                  <li class="nav-item">
                                   <button type="button" id="addNewMember" class="nav-link active btn btn-primary btn-sm target-member"  data-target="#membersModal">
                                Add new Member
                              </button>
                                  </li>
                              </ul>
															<hr/>
															<div id="member_table"> 
															<table class="table table-striped table-bordered dt-responsive nowrap members_list" style="width:100%;">
																<thead>
																	<tr>
																	<th>Serial no.</th>
																	<th>Name</th>
																	<th></th>
																	<th></th>
																</tr>
																</thead>
																<tbody>
																<?php  
	                               while($row = mysqli_fetch_array($result))  
	                               {  
                                  $i++;
	                               ?>  
	                               <tr>  
	                                    <td><?php echo $i; ?></td>  
	                                    <td><?php echo $row["surname"]." ".$row["firstname"]." ".$row["othername"] ; ?></td>  
	                                    <td><input type="button" name="edit" value="Edit" id="<?php echo $row["id"]; ?>" class="btn btn-info btn-xs edit_data target-member" /></td>  
	                                    <td><input type="button" name="view" value="view" id="<?php echo $row["id"]; ?>" class="btn btn-info btn-xs view_data" /></td>  
	                               </tr>  
	                               <?php  
	                               }  
	                               ?>  
	                               </tbody>
								   </table>
									</div>
													</div>
												</div>
	
											</div>
										</div>
									</div>
								</div>
						</div>
					</div>
				</div>
					<?php include_once('template/menu.php');?>
			</div>
</div>
	<footer class="footer mt-auto py-3"  style="background: #F0F0F0;">
		<div class="container">
			<center><p class="text-muted">Copyright &copy; 2020: All Rights</p></center>
		</div>
		
	</footer>
	<?php include_once('modals/members/members_add.php')?>
	<?php include_once('modals/members/members_details.php')?>
	<?php include_once('scripts/javascript.php')?>
<script>  
 $(document).ready(function(){  
      $('#addNewMember').click(function(){  
           $('#btnAddMember').val("Add Member");  
           $('#addmember_form')[0].reset();  
      });  
      $(document).on('click', '.edit_data', function(){  
           var member_id = $(this).attr("id");  
           $.ajax({  
                url:"app/members/fetch.php",  
                method:"POST",  
                data:{member_id:member_id},  
                dataType:"json",  
                success:function(data){  
                     $('#staffno').val(data.staffno);  
                     $('#firstname').val(data.firstname);  
                     $('#surname').val(data.surname);  
                     $('#othername').val(data.othername);  
                     $('#gender').val(data.gender);  
                     $('#marital_status').val(data.marital_status);  
                     $('#phoneno').val(data.phoneno);   
                     $('#address').val(data.address);  
                     $('#nok_name').val(data.nok_name);  
                     $('#nok_relationship').val(data.nok_relationship);  
                     $('#nok_address').val(data.nok_address);  
                     $('#member_id').val(data.id);  
                     $('#btnAddMember').val("Update");  
                     $('#membersModal').modal('show');  
                }  
           });  
      });  
      $('#addmember_form').on("submit", function(event){  
           event.preventDefault();  
           if($('#firstname').val() == "")  
           {  
               
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Firstname is required');
           } 
           else if($('#surname').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Surname is required'); 
           } 
           else if($('#gender').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Gender is required'); 
           } 
           else if($('#marital_status').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Marital Status is required'); 
           } 
           else if($('#phoneno').val() == '')
           {  
                //alert("Phone number is required"); 
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Phone number is required');  
           }
           else if($('#address').val() == '')
           {  
                //alert("Address is required");  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Address is required'); 
           }
           else if($('#nok_name').val() == '')
           {  
                //alert("Next of kin name is required"); 
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Next of kin name is required');  
           }
            else if($('#nok_relationship').val() == '')
           {    
                //alert("Next of kin relationship is required");
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Next of kin relationship is required');   
           }
           else if($('#nok_address').val() == '') 
           {    
                //alert("Next of kin address is required");
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Next of kin address is required');   
           }
           else  
           {  
                $.ajax({  
                     url:"app/members/insert.php",  
                     method:"POST",  
                     data:$('#addmember_form').serialize(),  
                     beforeSend:function(){  
                          $('#btnAddMember').val("Saving...");  
                     },  
                     success:function(data){  
                          $('#addmember_form')[0].reset();  
                          $('#membersModal').modal('hide');  
                          $('#member_table').html(data);  
                     }  
                });  
           }  
      });  
      $(document).on('click', '.view_data', function(){  
           var member_id = $(this).attr("id");  
           if(member_id != '')  
           {  
                $.ajax({  
                     url:"app/members/select.php",  
                     method:"POST",  
                     data:{member_id:member_id},  
                     success:function(data){  
                          $('#member_detail').html(data);  
                          $('#dataModal').modal('show');  
                     }  
                });  
           }            
      });

       $("#membersModal").modal({
        show: false,
        backdrop: 'static'
    });  
     // $('.members_list').dataTable({
     //    responsive: true
     // });
     $('.members_list').DataTable();
 });  
 </script>
 <script type="text/javascript">
    var $modal= $('.new-member-modal');

    $('.target-member').on('click', function (e) {
        $modal.css({top: e.clientY, left: e.clientX, transform: 'scale(0.1, 0.1)'});
        $modal.modal('show');
        $modal.css({top: '', left: '', transform: ''});
    });

    // $('#dismissModal').click(function(){
    // $modal.css({top: 0, left: 0, transform: 'scale(0.1, 0.1)', opacity:'0'});
    // setTimeout(function(){
    //     $('.new-member-modal').modal('hide')
    // },750);
    // });

    
    $modal.on('hide', function () {    
        $modal.css({top: 0, left: 0, transform: 'scale(0.1, 0.1)', opacity:'0'});
        return false;    // uncomment this line to see zoom out
    });
    

    $modal.on('hidden', function () {
        $modal.css({top: '', left: '', transform: '', opacity:''});
    });


 </script>
</body> 
</html>