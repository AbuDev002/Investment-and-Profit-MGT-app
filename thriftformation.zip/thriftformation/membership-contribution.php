<?php
  session_start();
  if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
      header('location:index.php');
  }
?>
 <?php 
 $i = 0; 
 include_once('connection.php'); 
 $query = "SELECT * FROM deposit ORDER BY id DESC";  
 $result = mysqli_query($connect, $query);  
 ?>
 <?php
function formatMoney($number, $fractional=false) {
    if ($fractional) {
        $number = sprintf('%.2f', $number);
    }
    while (true) {
        $replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
        if ($replaced != $number) {
            $number = $replaced;
        } else {
            break;
        }
    }
    return $number;
}
?>
<!Doctype html>
<html lang="en">
<?php include_once ('template/head.php')?>
<body>
	<?php include_once('template/header.php');?>
<div class="container">
<br/>
	<div class="container" style="padding: 0px;">
		<div class="row">
			<div class="col-md-9" style="min-height:520px;">
        <div class="card shadow p-3 mb-5 bg-white rounded"">
          <div class="card-header">MANAGE CONTRIBUTION</div>
          <div class="card-body">
            <?php
              include_once('connection.php');
              $result1 = mysqli_query($connect,"SELECT sum(amount) as total_contributions FROM deposit");
               $profit_gain = mysqli_fetch_array($result1);
            ?>  

            <form>
            <div class="form-row">
              <div class="col-md-4"></div>
              <div class="col-md-4">
                <button type="button" class="nav-link active btn btn-primary btn-sm btn-block btn-contribute" id="addNewContribution" data-target="#contributionModal" style="margin-bottom: 10px;">
                        Add Contribution
                            </button>
              </div>
              <div class="col-md-4">
                <button type="button" class="nav-link active btn btn-primary btn-sm btn-block btn-Totalcontribute" id="btnTotalContribution" data-target="#TotalcontributionModal">Total Contribution</button>
              </div>
            </div>
          </form>
            <!-- <div class="shadow-none table-responsive"> -->
              
          </div>
        </div>

				<div class="card" style="min-height: 500px; margin: 0px;">
					<div class="card-header" style="background: #F0F0F0;">
						<center><h5 class="card-title">CONTRIBUTIONS/SAVINGS</h5></center>
					</div>
						<div class="card-body">
					
									<hr>
                  <table class="table table-striped table-bordered dt-responsive nowrap contribution_table" id="contribution_table" style="width:100%;">
                        <thead>
                          <tr>
                            <th>S/N</th>
                            <th>Name of Member</th>
                            <th>Amount Contributed</th>
                            <th>Date Contributed</th>
                           <!--  <th>Total Contributions</th> -->
                          </tr>
                        </thead>
                        <tbody>
                        <?php  
                         while($row = mysqli_fetch_array($result))  
                         {  
                          $i++;
                         ?>  
                         <tr>  
                              <td><?php echo $i;?></td>  
                              <td>
                                <?php 
                                $getusername = mysqli_query($connect,"select * from members where id='".$row["users_id"]."'");
                                  $name = mysqli_fetch_array($getusername);
                                  echo $name['surname']." ".$name['firstname']." ".$name['othername'];
                                ?>
                              </td>  
                              <td><?php echo "&#8358; ".formatMoney($row["amount"], true);?></td>  
                              <td><?php echo $row["date_deposit"];?></td>
                              <!-- <td></td> -->
                         </tr>  
                         <?php } ?> 
                         </tbody>
                      </table>
										
									<!-- </div> -->
									
								
						</div>
				
				</div>
			</div>
				<?php include_once('template/menu.php');?>
		</div>
	</div>
 <!--</div>-->
 
  
</div>
<!-- </form> -->

<!--</div>-->

	

<?php include_once('template/footer.php');?>
<?php include_once('modals/contributions/member_contribute.php')?>
<?php include_once('modals/contributions/totalcontribution.php')?>
<?php include_once('scripts/javascript.php')?>
<script src="js/bootstrap-select.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $('.selectpicker').selectpicker();
  })
</script>
<script>  
 $(document).ready(function(){ 
 //$('.selectpicker').selectpicker(); 
      $('#addNewContribution').click(function(){  
           //$('#btnContribution').val("Save Contribution");  
           $('#ContributionForm')[0].reset();  
      });  
      // $(document).on('click', '.edit_data', function(){  
      //      var member_id = $(this).attr("id");  
      //      $.ajax({  
      //           url:"app/members/fetch.php",  
      //           method:"POST",  
      //           data:{member_id:member_id},  
      //           dataType:"json",  
      //           success:function(data){  
      //                $('#staffno').val(data.staffno);  
      //                $('#firstname').val(data.firstname);  
      //                $('#surname').val(data.surname);   
      //                $('#btnAddMember').val("Update");  
      //                $('#membersModal').modal('show');  
      //           }  
      //      });  
      // });  
      $('#ContributionForm').on("submit", function(event){  
           event.preventDefault();  
           if($('#selectpicker').val() == "")  
           {  
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Please select member'); 
           } 
           else if($('#amount').val() == '')
           {  
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Please enter amount contributed');  
           } 
            else if($('#amount').val() < 1000)
           {  
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Sorry minimute amount is N1000');  
           } 
           else if($('#date_deposite').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Please select date contributed'); 
           } 
           else  
           {  
                $.ajax({  
                     url:"app/investments/newcontribution.php",  
                     method:"POST",  
                     data:$('#ContributionForm').serialize(),  
                     beforeSend:function(){  
                          $('#btnContribution').val("Saving...");  
                     },  
                     success:function(data){  
                          $('#ContributionForm')[0].reset();  
                          $('#contributionModal').modal('hide');  
                          $('#contribution_table').html(data);  
                     }  
                });  
           }  
      });  
      // $(document).on('click', '.view_data', function(){  
      //      var member_id = $(this).attr("id");  
      //      if(member_id != '')  
      //      {  
      //           $.ajax({  
      //                url:"app/members/select.php",  
      //                method:"POST",  
      //                data:{member_id:member_id},  
      //                success:function(data){  
      //                     $('#member_detail').html(data);  
      //                     $('#dataModal').modal('show');  
      //                }  
      //           });  
      //      }          
      // });

       $("#contributionModal").modal({
        show: false,
        backdrop: 'static'
      });
      $("#TotalcontributionModal").modal({
        show: false,
        backdrop: 'static'
      });   
     $('.contribution_table').dataTable();
 });  
 </script>
 <script type="text/javascript">
    var $modal= $('.add-contribute-modal');
    var $totalcontributemodal= $('.total-contribute-modal');
    $('.btn-contribute').on('click', function (e) {
       $modal.modal('show');
    });

    $('.btn-Totalcontribute').on('click', function (e) {
        $totalcontributemodal.modal('show');
    });

    $modal.on('hidden', function () {
        $modal.css({top: '', left: '', transform: '', opacity:''});
    });

 </script>
 <script type="text/javascript">
// Material Select Initialization
$(document).ready(function() {
  /* validation */
    $("#check-contribution").validate({
        rules:
            {
                from: {
                    required: true,
                },
                to: {
                    required: true,
                },
            },
        messages:
            {
                from: "<span style='color: red'>Date From Required .</span>",
                to: "<span style='color: red'>Date To required.</span>",
            },
        submitHandler: checkContribution
    });
      /* validation */
     /* Check contribution */
    function checkContribution(){
                var data = $("#check-contribution").serialize();
                $.ajax({
                    type : 'POST',
                    url  : "app/investments/checkcontribution.php",
                    data : data,
                    dataType: "json",
                    beforeSend: function()
                    {
                        $("#working").html('<button class="btn btn-primary btn-block btnCalculate"><span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span> Calculating...</button>');
                    },
                    success :  function(response)
                    {
                      
                       if(response == null){ 
                        setTimeout(function () {
                          $(".displayTotal").val(0); 
                          $("#working").html('<button class="btn btn-primary btn-block btnCalculate">No contribution available</button>');
                         },2000);
                          //$('#check-contribution')[0].reset();
                          
                       }else{
                        setTimeout(function () {
                        $(".displayTotal").val(response.total_contributions);
                        $("#working").html('<button class="btn btn-primary btn-block btnCalculate">Track Contribution</button>');
                       },2000); 
                        //$('#check-contribution')[0].reset();
                        
                       }
                                    
                    }

                });
                return false;
            }
});
 </script>
</body>
</html>