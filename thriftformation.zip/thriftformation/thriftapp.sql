-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2021 at 07:14 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thriftapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_tracker`
--

CREATE TABLE `activity_tracker` (
  `id` int(11) NOT NULL,
  `activity_descrip` text NOT NULL,
  `activity_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `activity_tracker`
--

INSERT INTO `activity_tracker` (`id`, `activity_descrip`, `activity_date`, `user_id`) VALUES
(2, 'Login to the system', '2020-11-09 17:44:55', 1),
(4, 'Login to the system', '2020-11-09 17:54:13', 1),
(7, 'Login to the system', '2020-11-09 17:58:34', 1),
(9, 'Login to the system', '2020-11-09 17:59:26', 1),
(10, 'Login to the system', '2020-11-09 18:00:42', 1),
(11, 'Updated Aliyu Usman Bilya details in the system', '2020-11-09 18:01:02', 1),
(12, 'Added Abdullahi Ahmad Muktar to the system', '2020-11-09 18:02:20', 1),
(13, 'Inputed monthly contribution recieved from 2', '2020-11-09 18:07:44', 1),
(14, 'Login to the system', '2020-11-12 15:23:08', 1),
(15, 'Inputed monthly contribution recieved from Mohammed Hassan', '2020-11-12 15:42:28', 1),
(16, 'Shared profit for the month of 2020-10', '2020-11-12 16:22:25', 1),
(18, 'Recieved a loan repayment from  and balance remains 70000', '2020-11-12 18:12:02', 1),
(19, 'Recieved a loan repayment from    and balance remains 15000', '2020-11-12 18:14:30', 1),
(20, 'Recieved a loan repayment from Hackett Roberta rerum and balance remains 50000', '2020-11-12 18:15:16', 1),
(21, 'Added new category of commodities', '2020-11-12 18:22:57', 1),
(22, 'Issued commodity loan to Witting Bart dolor at 3000', '2020-11-12 18:34:23', 1),
(23, 'Issued commodity loan to Ahmad Abubakar Yusuf at 4000', '2020-11-12 18:42:56', 1),
(24, 'Recieved commodity loan repayment from    and balance remains 2000', '2020-11-12 18:49:42', 1),
(25, 'Recieved commodity loan repayment from Witting Bart dolor and balance remains 2000', '2020-11-12 18:51:45', 1),
(26, 'Recieved a loan repayment from McKenzie Judson est and balance remains 0', '2020-11-13 19:43:32', 1),
(27, 'Recieved commodity loan repayment from Ahmad Abubakar Yusuf and balance remains 1500', '2020-11-13 19:45:30', 1),
(28, 'Recieved commodity loan repayment from Ahmad Abubakar Yusuf and balance remains 0', '2020-11-13 19:48:13', 1),
(29, 'Login to the system', '2020-11-16 13:50:54', 1),
(30, 'Login to the system', '2020-11-17 15:25:00', 1),
(31, 'Issued a loan to Kozey Ashly quod', '2020-11-17 15:34:15', 1),
(32, 'Recieved a loan repayment from Kozey Ashly quod and balance remains 8000', '2020-11-17 15:34:41', 1),
(33, 'Recieved a loan repayment from Kozey Ashly quod and balance remains 1000', '2020-11-17 15:35:10', 1),
(34, 'Added new category of product in commodities', '2020-11-17 15:45:53', 1),
(35, 'Issued commodity loan to Kozey Ashly quod at 800', '2020-11-17 15:48:10', 1),
(36, 'Recieved commodity loan repayment from Kozey Ashly quod and balance remains 300', '2020-11-17 15:50:23', 1),
(37, 'Shared profit for the month of 2020-10', '2020-11-17 15:51:58', 1),
(38, 'Login to the system', '2020-11-19 10:43:59', 1),
(39, 'Login to the system', '2020-11-26 12:22:37', 1),
(40, 'Login to the system', '2020-12-08 10:38:30', 1),
(41, 'Shared profit for the month of 2020-10', '2020-12-08 15:09:07', 1),
(42, 'Login to the system', '2020-12-13 05:23:17', 1),
(43, 'Shared profit for the month of 2020-10', '2020-12-13 17:45:12', 1),
(44, 'Login to the system', '2020-12-14 09:55:49', 1),
(45, 'Login to the system', '2020-12-15 10:58:00', 1),
(46, 'Login to the system', '2020-12-16 11:49:43', 1),
(47, 'Recieved a loan repayment from Mayer Abdul nobis and balance remains 0', '2020-12-17 05:04:48', 1),
(48, 'Recieved a loan repayment from Kozey Ashly quod and balance remains 0', '2020-12-17 05:17:44', 1),
(49, 'Recieved a loan repayment from Nader Myrtice provident and balance remains 8000', '2020-12-17 05:19:25', 1),
(50, 'Recieved a loan repayment from Nader Myrtice provident and balance remains 6000', '2020-12-17 05:20:31', 1),
(51, 'Shared profit for the month of 2020-10', '2020-12-17 05:30:06', 1),
(52, 'Recieved commodity loan repayment from Kozey Ashly quod and balance remains 0', '2020-12-17 05:32:28', 1),
(53, 'Login to the system', '2020-12-18 17:33:32', 1),
(54, 'Login to the system', '2020-12-20 11:45:31', 1),
(55, 'Issued a loan to Jacobi Art ut', '2020-12-21 12:23:01', 1),
(56, 'Recieved a loan repayment from Jacobi Art ut and balance remains 13000', '2020-12-21 12:23:35', 1),
(57, 'Login to the system', '2020-12-21 12:46:01', 1),
(58, 'Issued a loan to Lebsack Ross enim', '2020-12-21 13:43:42', 1),
(59, 'Issued a loan to Nader Myrtice provident', '2020-12-21 13:44:00', 1),
(60, 'Issued a loan to Roob Charlene vero', '2020-12-21 13:44:22', 1),
(61, 'Issued a loan to Vandervort Demarcus sint', '2020-12-21 13:44:51', 1),
(62, 'Issued a loan to Erdman Sonny illo', '2020-12-22 07:24:21', 1),
(63, 'Login to the system', '2020-12-22 10:52:11', 1),
(64, 'Login to the system', '2020-12-22 11:10:16', 1),
(65, 'Login to the system', '2020-12-22 11:11:10', 1),
(66, 'Login to the system', '2020-12-22 11:12:19', 1),
(67, 'Shared profit for the month of 2020-10', '2020-12-22 11:13:35', 1),
(68, 'Login to the system', '2020-12-22 11:13:52', 1),
(69, 'Inputed monthly contribution recieved from Windler Abel eius', '2020-12-22 11:14:22', 1),
(70, 'Login to the system', '2020-12-22 11:21:17', 1),
(71, 'Login to the system', '2020-12-22 15:36:39', 1),
(72, 'Shared profit for the month of 2020-10', '2020-12-22 15:38:37', 1),
(73, 'Issued a loan to Pagac Edwin atque', '2020-12-22 15:42:06', 1),
(74, 'Recieved a loan repayment from Pagac Edwin atque and balance remains 35000', '2020-12-22 15:42:51', 1),
(75, 'Login to the system', '2020-12-23 05:07:04', 1),
(76, 'Login to the system', '2021-01-18 06:14:49', 1),
(77, 'Login to the system', '2021-01-18 14:36:12', 1),
(78, 'Login to the system', '2021-01-19 12:57:56', 1),
(79, 'Recieved a loan repayment from Erdman Sonny illo and balance remains 95000', '2021-01-19 13:04:17', 1),
(80, 'Recieved a loan repayment from Erdman Sonny illo and balance remains 84000', '2021-01-19 13:51:07', 1),
(81, 'Login to the system', '2021-01-20 07:31:27', 1),
(82, 'Shared profit for the month of 2020-10', '2021-01-20 11:41:59', 1),
(83, 'Added new category of product in commodities', '2021-01-20 15:32:54', 1),
(84, 'Added new product in commodities', '2021-01-21 08:24:42', 1),
(85, 'Added new category of product in commodities', '2021-01-21 08:25:03', 1),
(86, 'Login to the system', '2021-01-23 17:50:32', 1),
(87, 'Login to the system', '2021-01-31 16:35:52', 1),
(88, 'Login to the system', '2021-02-08 09:49:09', 1),
(89, 'Login to the system', '2021-02-19 09:39:53', 1),
(90, 'Shared profit for the month of 2020-10', '2021-02-19 09:41:48', 1),
(91, 'Recieved a loan repayment from Pagac Edwin atque and balance remains 32800', '2021-02-19 09:43:31', 1);

-- --------------------------------------------------------

--
-- Table structure for table `adminusers`
--

CREATE TABLE `adminusers` (
  `userid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `lastlogin` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminusers`
--

INSERT INTO `adminusers` (`userid`, `name`, `username`, `password`, `lastlogin`) VALUES
(1, 'Administrator', 'admin', '5f4dcc3b5aa765d61d8327deb882cf99', '2020-11-12 16:23:15'),
(2, 'aliyu', 'user1', '5f4dcc3b5aa765d61d8327deb882cf99', '2020-07-24 15:36:52');

-- --------------------------------------------------------

--
-- Table structure for table `bankinfo`
--

CREATE TABLE `bankinfo` (
  `id` int(11) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountname` varchar(100) NOT NULL,
  `accountnumber` varchar(100) NOT NULL,
  `member_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `commodities_loan`
--

CREATE TABLE `commodities_loan` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `date_recieved` varchar(100) NOT NULL,
  `percent_charges` varchar(100) NOT NULL,
  `loan_duration` varchar(100) NOT NULL,
  `loan_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `commodities_loan`
--

INSERT INTO `commodities_loan` (`id`, `member_id`, `product_id`, `product_price`, `date_recieved`, `percent_charges`, `loan_duration`, `loan_status`) VALUES
(1, 99, 3, '5000', '', '0', '1', 1),
(2, 2, 11, '2500', '2020-11-04', '0', '1', 1),
(3, 6, 9, '2000', '2020-11-06', '2000', '1', 0),
(4, 14, 16, '2500', '2020-11-05', '1000', '1', 0),
(5, 1, 3, '5000', '2020-11-12', '2000', '1', 0),
(6, 99, 11, '2500', '2020-11-12', '0', '1', 1),
(7, 2, 8, '1250', '2020-11-17', '0', '1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `deposit`
--

CREATE TABLE `deposit` (
  `id` int(10) NOT NULL,
  `users_id` int(10) DEFAULT 0,
  `amount` decimal(10,2) DEFAULT 0.00,
  `date_deposit` varchar(100) DEFAULT NULL,
  `date_captured` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deposit`
--

INSERT INTO `deposit` (`id`, `users_id`, `amount`, `date_deposit`, `date_captured`) VALUES
(1, 1, '20000.00', '2020-10', '2020-10-17 16:16:59'),
(2, 4, '4000.00', '2020-10', '2020-10-17 16:17:23'),
(3, 6, '2000.00', '2020-09', '2020-10-17 16:17:34'),
(4, 5, '3000.00', '2020-09', '2020-10-17 16:17:59'),
(5, 103, '15000.00', '2020-10', '2020-10-27 11:24:16'),
(6, 2, '20000.00', '2020-10', '2020-11-09 18:07:44'),
(7, 102, '4000.00', '2020-11', '2020-11-12 15:42:28'),
(8, 3, '30000.00', '2020-12', '2020-12-22 11:14:22');

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `id` int(11) NOT NULL,
  `date_collected` varchar(100) NOT NULL,
  `amt` varchar(100) NOT NULL,
  `interest` varchar(100) NOT NULL,
  `exp_interest` varchar(100) NOT NULL,
  `member_id` int(11) NOT NULL,
  `exp_amt` varchar(100) NOT NULL,
  `loan_duration` varchar(100) NOT NULL,
  `balance` varchar(100) NOT NULL,
  `loan_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`id`, `date_collected`, `amt`, `interest`, `exp_interest`, `member_id`, `exp_amt`, `loan_duration`, `balance`, `loan_status`) VALUES
(3, '2020-10-14', '20000', '10', '2149.56', 5, '50000', '2', '20000', 0),
(4, '2020-10-14', '40000', '15', '9918.07', 7, '49918.07', '3', '40000', 0),
(5, '2020-10-14', '50000', '10', '5373.91', 99, '55373.91', '2', '50000', 0),
(6, '2020-10-22', '30000', '10', '1649.72', 2, '0', '1', '30000', 1),
(7, '2020-10-20', '60000', '10', '6000', 5, '50000', '', '60000', 0),
(8, '2020-10-21', '20000', '10', '2000', 4, '6000', '', '20000', 0),
(9, '2020-10-21', '40000', '10', '4000', 24, '0', '', '40000', 1),
(10, '2020-11-12', '90000', '10', '9000', 11, '0', '', '90000', 1),
(11, '2020-11-17', '8000', '10', '800', 2, '0', '', '8000', 1),
(12, '2020-12-21', '30000', '10', '3000', 25, '13000', '', '30000', 0),
(13, '2020-12-15', '10000', '10', '1000', 33, '11000', '', '10000', 0),
(14, '2020-12-21', '25000', '10', '2500', 4, '27500', '', '25000', 0),
(15, '2020-12-09', '40000', '10', '4000', 53, '44000', '', '40000', 0),
(16, '2020-12-19', '50000', '10', '5000', 76, '55000', '', '50000', 0),
(17, '2020-12-21', '100000', '10', '10000', 48, '84000', '', '100000', 0),
(18, '2020-12-22', '50000', '10', '5000', 12, '32800', '', '50000', 0);

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `staffno` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `othername` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `marital_status` varchar(100) NOT NULL,
  `phoneno` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `nok_name` varchar(100) NOT NULL,
  `nok_address` text NOT NULL,
  `address` text NOT NULL,
  `nok_phoneno` varchar(100) NOT NULL,
  `nok_relationship` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `date_registered` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `staffno`, `firstname`, `surname`, `othername`, `gender`, `marital_status`, `phoneno`, `email`, `nok_name`, `nok_address`, `address`, `nok_phoneno`, `nok_relationship`, `status`, `date_registered`) VALUES
(1, '', 'Bart', 'Witting', 'dolor', '', 'Quisquam ab accusamus quis quia repellat et. Illum voluptates temporibus quo rem soluta sapiente. Es', '+78(6)7287992789', 'torp.janessa@example.org', 'quia', '', '', '06991154972', '', 1, '2020-10-13 16:23:23'),
(2, '', 'Ashly', 'Kozey', 'quod', '', 'Pariatur quo dignissimos consectetur quo beatae dolor saepe. Est consequatur consequuntur consectetu', '(999)122-5774x46503', 'qkshlerin@example.org', 'mollitia', '', '', '1-376-868-3237x232', '', 0, '2015-12-16 11:16:17'),
(3, '', 'Abel', 'Windler', 'eius', '', 'Tempore eos repudiandae explicabo cupiditate doloremque. Quae atque porro atque iure. Eius molestiae', '1-117-189-0007', 'zhagenes@example.net', 'voluptatem', '', '', '868-891-8827x707', '', 0, '2018-09-12 05:38:51'),
(4, '', 'Myrtice', 'Nader', 'provident', '', 'Inventore neque voluptatibus dolorum. Dolorem eum enim veritatis harum. Placeat animi veniam in a qu', '555-881-3919', 'howe.kristoffer@example.net', 'impedit', '', '', '975-268-9298', '', 0, '1985-12-16 07:55:49'),
(5, '', 'Roberta', 'Hackett', 'rerum', '', 'Veritatis sed maxime voluptate molestiae iusto. Blanditiis voluptas delectus ipsam deleniti. Fugit p', '267.661.0853x7897', 'douglas.everardo@example.org', 'magnam', '', '', '(935)454-8358', '', 0, '2016-05-27 19:12:48'),
(6, '', 'Trisha', 'Lemke', 'sint', '', 'Ea deserunt sit sint dignissimos. Inventore incidunt excepturi ut aperiam modi deleniti. Ut tempora ', '1-844-924-6475', 'marks.jacklyn@example.com', 'alias', '', '', '(574)728-1396x81243', '', 0, '2010-03-07 23:52:15'),
(7, '', 'Buster', 'Torphy', 'ducimus', '', 'Ipsa corporis quos veniam rem minus quis in. Sint magnam repudiandae et. Et maxime aut voluptates qu', '1-131-157-9285x44277', 'bins.kailee@example.net', 'placeat', '', '', '628.368.8769', '', 0, '2008-10-18 19:13:56'),
(8, '', 'Evan', 'Cronin', 'voluptatem', '', 'Deleniti doloremque qui voluptatem culpa sunt suscipit ducimus. Est quibusdam molestiae ut ducimus a', '(639)189-6663x7510', 'wilkinson.daisha@example.com', 'adipisci', '', '', '1-598-916-1828', '', 0, '1976-02-22 14:26:20'),
(9, '', 'Darien', 'Roberts', 'esse', '', 'Quo architecto impedit odit saepe nostrum ut officiis ratione. Vel aut facere autem quo debitis. In ', '06859362674', 'tia.boyle@example.org', 'cumque', '', '', '674.055.8010', '', 0, '2018-08-15 18:16:39'),
(10, '', 'Elody', 'Shanahan', 'illo', '', 'Harum debitis quas dolores ad sit ipsa. Quo et cupiditate repudiandae corrupti. Tempora soluta tempo', '394-210-5620x885', 'antonina.hudson@example.net', 'quidem', '', '', '(164)818-2422x67835', '', 0, '1982-06-22 16:09:29'),
(11, '', 'Judson', 'McKenzie', 'est', '', 'Sit fuga dolores voluptatem et. Explicabo quia magni perspiciatis quae sint. Qui fuga qui laudantium', '(034)637-2279x2033', 'fanny.hirthe@example.net', 'libero', '', '', '967.855.5530', '', 0, '1972-11-15 15:26:05'),
(12, '', 'Edwin', 'Pagac', 'atque', '', 'Fugiat eveniet praesentium aut omnis. Aut tempore deleniti aliquam.', '02878128577', 'zschultz@example.com', 'unde', '', '', '833.079.5522', '', 0, '2008-04-01 00:24:59'),
(13, '', 'Jeramie', 'Witting', 'voluptatibus', '', 'Quas nam placeat voluptates qui ut. Ut quae sit quasi odio ut. Perspiciatis odio soluta architecto a', '374.803.1383', 'mraz.richard@example.com', 'ut', '', '', '725.549.9663x8740', '', 0, '1978-09-18 06:57:43'),
(14, '', 'Isidro', 'Mosciski', 'sed', '', 'Hic et alias aliquid commodi rerum dolor cumque excepturi. Voluptatem quia et similique velit. Tempo', '543.528.0787x941', 'domenico02@example.org', 'itaque', '', '', '(762)640-6128x9268', '', 0, '2002-10-16 14:53:50'),
(15, '', 'Ezra', 'Murray', 'ab', '', 'Illum incidunt veritatis dignissimos ullam modi. Velit commodi quidem necessitatibus est quibusdam c', '708.547.5299', 'devon.lemke@example.net', 'veritatis', '', '', '1-706-208-0719', '', 0, '1981-08-30 17:57:53'),
(16, '', 'Floy', 'Pagac', 'accusantium', '', 'Quisquam excepturi perferendis eligendi et non ipsam. Aperiam amet doloribus in quos quo perferendis', '1-383-766-3900x4579', 'devan70@example.com', 'dolores', '', '', '1-649-363-6706', '', 0, '1977-11-12 15:03:55'),
(17, '', 'Elijah', 'Streich', 'eligendi', '', 'Ad sit soluta in modi sit placeat numquam. Libero doloremque aut similique. Nisi est autem sed.', '1-777-906-3974x1123', 'mprice@example.net', 'dolores', '', '', '1-974-430-1325', '', 0, '1993-06-14 18:29:53'),
(18, '', 'Joanny', 'Haag', 'maxime', '', 'Voluptas laboriosam voluptatem recusandae dolorum natus itaque ea. Quas quis doloribus qui doloribus', '545.817.1336', 'myrna.weissnat@example.net', 'natus', '', '', '606-451-3056', '', 0, '1987-01-16 11:59:01'),
(19, '', 'Walter', 'Rice', 'et', '', 'Et consequatur sunt ad labore tempore molestiae. Non ex sapiente explicabo quia. Et sint molestiae e', '077-019-9922x814', 'mozelle14@example.net', 'quibusdam', '', '', '+51(3)8611881583', '', 0, '2016-08-13 12:18:47'),
(20, '', 'Katrina', 'Larkin', 'beatae', '', 'Cum temporibus quia ut eius rerum quam. Eos voluptas vitae qui qui sequi eum. Rem culpa optio verita', '361-665-8339x388', 'fadel.neha@example.org', 'animi', '', '', '808-945-7052x73199', '', 0, '2013-06-23 21:18:54'),
(21, '', 'Tyler', 'Moore', 'est', '', 'Quos non dolores nemo eos a ratione ex. Hic qui id aliquid saepe commodi quod aut. Hic animi quas ha', '+09(8)0820272995', 'lauryn.conroy@example.com', 'omnis', '', '', '(240)198-4219', '', 0, '1989-12-24 19:37:54'),
(22, '', 'Roxane', 'Schuster', 'explicabo', '', 'Facilis aperiam voluptatem itaque quae nostrum tempora. Illum et molestias quaerat eius quis id.', '1-703-875-4455x52974', 'armstrong.annetta@example.net', 'et', '', '', '810.863.5295x8724', '', 0, '2003-03-31 10:45:01'),
(23, '', 'Eric', 'Zieme', 'nobis', '', 'Deserunt quas quis sit ut mollitia. Porro vel aperiam quia voluptas nam dolores.', '096-470-7963', 'ziemann.reagan@example.net', 'sunt', '', '', '745-867-7861', '', 0, '2018-11-02 10:06:27'),
(24, '', 'Abdul', 'Mayer', 'nobis', '', 'Illo quasi velit repellat tempora. Qui eos ab qui dolor ut.', '(170)538-4908', 'imogene.marquardt@example.org', 'sapiente', '', '', '112.263.1163x2636', '', 0, '2008-09-01 20:27:51'),
(25, '', 'Art', 'Jacobi', 'ut', '', 'Consequatur minus dolore culpa quia numquam doloribus voluptatem. Dolor animi veniam dolorum suscipi', '584-969-1715x260', 'sherman.friesen@example.net', 'dolor', '', '', '155-820-0694x770', '', 0, '2001-10-01 11:59:25'),
(26, '', 'Neal', 'Brakus', 'hic', '', 'Error voluptatem nihil est nemo beatae accusamus. Sit quia necessitatibus ratione illum animi. Provi', '1-571-159-0491x3171', 'webster26@example.org', 'dolore', '', '', '150.118.0655x8515', '', 0, '2000-11-18 12:28:39'),
(27, '', 'Marta', 'Feeney', 'iusto', '', 'Libero quisquam suscipit ea et consequatur. Nihil eos illo doloremque recusandae. Autem corrupti asp', '(718)268-6934', 'herzog.odie@example.com', 'quis', '', '', '(145)896-9016x77357', '', 0, '2017-03-29 15:31:55'),
(28, '', 'Brice', 'Rowe', 'sit', '', 'Eos sequi et reiciendis et nulla. Consequatur nulla atque explicabo cum et facere ipsa neque. Quo di', '1-195-085-6863x55962', 'fvandervort@example.org', 'doloribus', '', '', '1-784-747-9375x49159', '', 0, '1995-01-09 12:19:51'),
(29, '', 'Cristobal', 'Klein', 'ad', '', 'Recusandae rerum qui eum sunt. Ut rerum maxime voluptas deserunt et beatae. A recusandae aspernatur ', '(410)990-0640x749', 'erempel@example.net', 'quia', '', '', '1-845-991-0943x2561', '', 0, '2019-12-26 23:50:56'),
(30, '', 'Lenora', 'Dietrich', 'cumque', '', 'Deleniti adipisci deleniti eos enim qui vel voluptatem laudantium. Sapiente hic velit rerum ullam ad', '1-338-079-9606x1450', 'leonor.zemlak@example.org', 'adipisci', '', '', '080.042.2955x1295', '', 0, '1978-10-02 02:52:38'),
(31, '', 'Casey', 'Dach', 'accusantium', '', 'Exercitationem et vitae autem rerum. Dolor non voluptatem dolorum et eos incidunt quidem cupiditate.', '07754428273', 'geovany48@example.com', 'dolores', '', '', '08048555043', '', 0, '2008-05-04 20:25:46'),
(32, '', 'Ocie', 'Kihn', 'sed', '', 'Dolore quis ut quo vero est soluta illum. Pariatur deleniti blanditiis dolorem natus. Aspernatur des', '+89(9)8294131650', 'stamm.santa@example.com', 'praesentium', '', '', '859-196-9866', '', 0, '1975-06-01 09:20:56'),
(33, '', 'Ross', 'Lebsack', 'enim', '', 'Ut dolorem unde id qui distinctio id distinctio distinctio. Voluptatem qui magni quia quo est iste c', '1-255-873-2019', 'ukassulke@example.net', 'amet', '', '', '(586)307-9125x199', '', 0, '2016-11-24 13:33:12'),
(34, '', 'Sonya', 'Wilkinson', 'id', '', 'Vel voluptatem id quos tempora ut. Rerum ullam doloribus rem ut dolorem alias. Nesciunt perferendis ', '05471705088', 'hpagac@example.net', 'necessitatibus', '', '', '(439)615-0821x1817', '', 0, '1982-06-30 15:12:55'),
(35, '', 'Eve', 'Rolfson', 'laudantium', '', 'Aliquam non id quidem ut. Quos laboriosam et et provident rem animi. Eos dicta deserunt consequatur ', '239.199.5662x44496', 'ykoss@example.org', 'quod', '', '', '(766)030-7938x942', '', 0, '2014-09-04 11:54:04'),
(36, '', 'Janelle', 'Kemmer', 'rerum', '', 'Minus consectetur ipsam esse temporibus. Deleniti veritatis quidem dolor saepe. Vitae voluptatibus i', '1-825-471-2843', 'bhammes@example.net', 'molestiae', '', '', '(091)939-2655x65656', '', 0, '1984-05-25 18:48:01'),
(37, '', 'Monte', 'Brown', 'perferendis', '', 'Facere repellendus aliquid eius quia mollitia. Quia fuga tenetur a laborum officiis doloribus eum. S', '1-446-868-1060', 'abernathy.brianne@example.org', 'assumenda', '', '', '594-760-8001x5283', '', 0, '2020-05-29 00:30:34'),
(38, '', 'Marilyne', 'Franecki', 'in', '', 'Corporis ut voluptatem veritatis veniam eius consequatur dolore. Cum fuga ut accusamus deserunt dolo', '+25(3)5545259284', 'bgoodwin@example.com', 'repellendus', '', '', '(139)005-8428x36403', '', 0, '1997-07-13 07:43:59'),
(39, '', 'Mariano', 'Torp', 'enim', '', 'Dolores et ex qui voluptatem dolorum. Deleniti expedita eius dolore rerum. Quaerat autem voluptatum ', '(612)213-7163x00454', 'milford88@example.com', 'repellat', '', '', '(966)193-5877', '', 0, '1999-02-04 12:48:22'),
(40, '', 'Salvatore', 'Nader', 'omnis', '', 'Harum optio rerum ex qui cum quae facere. Earum officia enim cumque blanditiis. Consequatur est even', '478-351-4632', 'candido37@example.org', 'nihil', '', '', '+34(0)6950079997', '', 0, '1972-04-26 04:14:43'),
(41, '', 'Mauricio', 'O\'Keefe', 'sunt', '', 'Aut modi distinctio ut quo veniam nam natus corporis. Illo qui id est est est dolores labore rerum. ', '07974234148', 'cletus31@example.com', 'esse', '', '', '1-526-019-0563x959', '', 0, '1985-07-01 10:39:55'),
(42, '', 'Hoyt', 'Morissette', 'quos', '', 'Quisquam atque a et quidem. Quis non provident minima corporis voluptas eaque quia. Dolorem a aut re', '(852)610-6658', 'elmer.littel@example.net', 'temporibus', '', '', '1-944-737-8581x330', '', 0, '1970-10-18 06:12:00'),
(43, '', 'Queen', 'Hammes', 'et', '', 'Quia et eveniet ratione exercitationem. Unde earum ab nesciunt consequuntur alias. Reiciendis magnam', '532.888.7743', 'vo\'reilly@example.org', 'optio', '', '', '08274525624', '', 0, '2002-01-27 19:53:22'),
(44, '', 'Winnifred', 'Zieme', 'vel', '', 'Iusto aut sit sit praesentium officiis. Sunt debitis recusandae quo sequi reiciendis. Similique labo', '894-223-9357x3555', 'davon.o\'keefe@example.com', 'delectus', '', '', '394-136-8377x6885', '', 0, '2013-05-11 03:13:46'),
(45, '', 'Diamond', 'Davis', 'enim', '', 'Quisquam in perspiciatis voluptates est ut vel. Dicta qui et aperiam nulla. Et doloribus excepturi s', '411.474.4452', 'qbradtke@example.org', 'nesciunt', '', '', '1-639-783-1859x506', '', 0, '1974-06-18 15:49:43'),
(46, '', 'Isidro', 'Gibson', 'vero', '', 'Nihil temporibus repellat esse ad nam vitae doloribus. Nesciunt optio necessitatibus consequatur et ', '01123655379', 'morissette.cielo@example.net', 'nemo', '', '', '1-563-795-1540', '', 0, '1994-01-04 04:23:57'),
(47, '', 'Tillman', 'Brakus', 'quisquam', '', 'Sunt veniam aliquam cumque pariatur. Facilis accusantium omnis animi tempore vitae et quas. Ducimus ', '165-499-6621x748', 'louisa.gislason@example.org', 'quis', '', '', '+38(2)7559679814', '', 0, '2000-04-11 14:19:32'),
(48, '', 'Sonny', 'Erdman', 'illo', '', 'Aperiam ipsa voluptas quisquam rem laudantium non eum. Culpa et aperiam rem. Ut molestiae nobis quo ', '+47(6)8012700972', 'richmond.goodwin@example.org', 'nisi', '', '', '456.374.7458', '', 0, '1981-01-27 14:33:06'),
(49, '', 'Katlynn', 'Hegmann', 'fuga', '', 'Eos quia sint voluptates adipisci. Dolorem et et rerum officia tempora. Unde ut sit commodi aspernat', '458.461.4502x6209', 'bahringer.allene@example.org', 'omnis', '', '', '1-229-577-3764', '', 0, '2011-09-08 08:55:54'),
(50, '', 'Elvie', 'Jenkins', 'nemo', '', 'Itaque molestiae quo maiores dignissimos sit at animi quisquam. Cum vero omnis voluptatibus non dict', '+65(5)3492892422', 'adelia.ortiz@example.net', 'vel', '', '', '+61(0)1942163813', '', 0, '2005-06-01 15:08:40'),
(51, '', 'Stanton', 'Walsh', 'laudantium', '', 'Qui et voluptatem assumenda. Quasi esse voluptatem fuga.', '08919897861', 'elouise.jaskolski@example.com', 'est', '', '', '190.586.6430x256', '', 0, '1999-08-05 20:24:35'),
(52, '', 'Brenden', 'Breitenberg', 'in', '', 'Et dignissimos velit veritatis sint. Quas voluptatem qui fugit labore optio. Commodi dolores aperiam', '1-803-987-3294x376', 'clifford.emard@example.org', 'molestiae', '', '', '1-121-323-1084x86998', '', 0, '2003-07-28 04:22:31'),
(53, '', 'Charlene', 'Roob', 'vero', '', 'Dolores sed iusto quis. Et aliquid ratione aut vitae enim. Placeat eos mollitia ab quisquam fuga rer', '649.485.7152', 'kaitlyn.crooks@example.net', 'perspiciatis', '', '', '647.045.7698', '', 0, '1971-08-06 09:12:58'),
(54, '', 'Rogelio', 'Fisher', 'sint', '', 'Sint accusantium voluptatibus ut maiores. Soluta at qui repudiandae quod deserunt vel. Dolor quos pr', '311.409.9178x040', 'rlockman@example.org', 'a', '', '', '+30(3)4468813680', '', 0, '1972-10-21 13:31:12'),
(55, '', 'Keanu', 'Denesik', 'natus', '', 'Sequi repudiandae voluptates quasi asperiores et iusto. Odit accusamus consequuntur recusandae quo d', '1-103-470-8941', 'glover.kaela@example.net', 'qui', '', '', '442-826-2318x2057', '', 0, '1982-11-11 17:16:10'),
(56, '', 'Ryleigh', 'Ziemann', 'ipsam', '', 'Repellat quo eius sed corrupti. Voluptatibus enim ut sed est.', '1-873-782-7182x568', 'patsy.halvorson@example.net', 'soluta', '', '', '(999)271-3897x300', '', 0, '1972-03-17 08:29:50'),
(57, '', 'Braulio', 'Toy', 'autem', '', 'Laudantium voluptas sit nobis voluptatibus. Eligendi enim cumque sint est natus in. Consectetur fugi', '960.999.8243', 'jacobi.morgan@example.net', 'sed', '', '', '979.412.0086x97827', '', 0, '2010-01-25 17:27:13'),
(58, '', 'Noemi', 'O\'Keefe', 'ut', '', 'Dignissimos impedit hic et dolorem consequuntur nihil. Sequi et eius atque omnis libero quia. Id quo', '(656)802-6268', 'ykozey@example.com', 'id', '', '', '(095)716-6993x04499', '', 0, '1996-09-27 11:19:59'),
(59, '', 'Ladarius', 'O\'Connell', 'ab', '', 'Voluptatem in facere quia et dolor. At dolorem deleniti sapiente tempore ab. Quia voluptas aperiam v', '(301)739-5608x587', 'hayes.adella@example.net', 'quae', '', '', '947.330.0279', '', 0, '1981-10-04 20:31:16'),
(60, '', 'Jane', 'Daniel', 'veritatis', '', 'Cum deserunt quod ipsam. Quis eos illum in sapiente minus. Amet velit totam quos commodi.', '959-204-2701', 'rupton@example.net', 'tempore', '', '', '09277435493', '', 0, '1978-04-04 17:11:41'),
(61, '', 'Johnathon', 'Price', 'id', '', 'Qui facere ex nobis aut exercitationem autem unde. Provident unde asperiores tempore expedita dolore', '198-323-9649', 'lhermiston@example.org', 'magnam', '', '', '+95(2)9413194642', '', 0, '2016-12-21 02:03:58'),
(62, '', 'Sedrick', 'Will', 'et', '', 'Nemo quo atque debitis aliquid rerum eos distinctio. Ipsa qui neque eius in odio. Non rem atque aut ', '236.397.1071', 'cullen38@example.com', 'quia', '', '', '(981)330-7415', '', 0, '2001-09-26 06:14:33'),
(63, '', 'Emely', 'Gulgowski', 'facere', '', 'Nostrum itaque voluptas repudiandae et quo eius reprehenderit. Perferendis delectus unde est dicta. ', '(606)719-6052', 'sunny60@example.org', 'iste', '', '', '1-860-660-4485', '', 0, '2017-11-15 20:56:39'),
(64, '', 'Tate', 'Eichmann', 'recusandae', '', 'Ad fuga occaecati earum quisquam libero doloremque. Et et pariatur nemo aliquam aut sunt sit. Odit v', '00928607346', 'carolyn80@example.net', 'sed', '', '', '1-807-198-3000x0124', '', 0, '1976-07-20 03:28:11'),
(65, '', 'Troy', 'Pacocha', 'natus', '', 'Ullam blanditiis ea sed autem ut id repellat ut. Sequi qui impedit amet soluta quia maxime. Eligendi', '1-980-881-8009x2043', 'antonetta.denesik@example.net', 'amet', '', '', '(611)457-1432x810', '', 0, '1979-02-07 22:36:51'),
(66, '', 'Ressie', 'Schroeder', 'deserunt', '', 'Et pariatur porro beatae voluptate ex error. Natus accusamus harum perspiciatis id ipsum nesciunt be', '(948)512-4616x27332', 'benedict.lakin@example.org', 'quidem', '', '', '320-462-6213', '', 0, '1971-08-08 15:57:58'),
(67, '', 'Caroline', 'Hermiston', 'dicta', '', 'Reiciendis est autem odit in velit quia. Aut necessitatibus sit mollitia explicabo eius velit blandi', '1-570-445-7420x324', 'morris72@example.net', 'sequi', '', '', '1-681-019-0189', '', 0, '1984-07-18 10:21:34'),
(68, '', 'Ernestina', 'Shields', 'aut', '', 'Nobis sequi at rerum molestiae in quidem. Tempore aut accusamus et qui aspernatur eligendi odit. Qui', '06180974317', 'shauck@example.net', 'qui', '', '', '316.578.4964', '', 0, '1981-06-27 23:25:44'),
(69, '', 'Brant', 'Runolfsson', 'beatae', '', 'Fugit unde est qui aliquid sed. Magnam enim laudantium qui eveniet. Quae voluptatem aliquid hic aspe', '324.222.8438', 'kade.prosacco@example.org', 'qui', '', '', '1-045-934-4487x38536', '', 0, '2011-06-29 01:32:06'),
(70, '', 'Oswaldo', 'Gottlieb', 'aliquam', '', 'Quaerat eius voluptatem laborum voluptate cumque cumque. Iusto cum odit aliquid impedit voluptates. ', '843.926.3706x1687', 'terrence.klein@example.net', 'vel', '', '', '+32(3)9234211369', '', 0, '2007-06-07 15:52:45'),
(71, '', 'Andres', 'Bins', 'eligendi', '', 'Expedita cumque quaerat distinctio vel et et. Soluta animi ut ipsum nulla et. Dignissimos beatae sit', '1-090-903-3429', 'jennie.mclaughlin@example.org', 'exercitationem', '', '', '1-034-244-3138x91687', '', 0, '2019-02-13 18:36:10'),
(72, '', 'Lindsay', 'Reichert', 'reprehenderit', '', 'Porro placeat nobis incidunt ea. Ex possimus dolores et ipsam nisi. Itaque et maxime iure nisi volup', '424-112-5661x57350', 'alta94@example.com', 'omnis', '', '', '520.073.6799x307', '', 0, '2011-09-13 11:01:44'),
(73, '', 'Marc', 'Legros', 'cupiditate', '', 'Alias vero numquam amet et laboriosam sed. Qui perferendis quibusdam nisi unde. Adipisci voluptas su', '139.099.1457x7412', 'angelica24@example.net', 'laboriosam', '', '', '+37(5)2726062086', '', 0, '1991-11-15 01:01:28'),
(74, '', 'Maya', 'Anderson', 'qui', '', 'Sint voluptatem sit alias aspernatur. Placeat commodi at illo magni in illo maxime. Consequatur reru', '(721)912-5014x053', 'herminio.vandervort@example.net', 'sit', '', '', '288-359-1286', '', 0, '2011-08-14 05:17:14'),
(75, '', 'Angie', 'Rath', 'ut', '', 'Suscipit temporibus accusamus temporibus et vero. Aut qui praesentium excepturi earum mollitia. Mole', '787-480-6119x25222', 'hagenes.fermin@example.org', 'dignissimos', '', '', '04757694230', '', 0, '2013-01-14 02:03:41'),
(76, '', 'Demarcus', 'Vandervort', 'sint', '', 'Repellendus repudiandae dicta alias similique recusandae explicabo. Qui autem sed laudantium numquam', '486-324-6086', 'bschumm@example.org', 'explicabo', '', '', '+55(4)2364629840', '', 0, '1981-02-18 17:58:45'),
(77, '', 'Duncan', 'Kirlin', 'ut', '', 'Nisi dignissimos in laborum et. Sit illum possimus minus quos atque commodi necessitatibus. Dolorem ', '693-614-9960x68692', 'chaz.grady@example.org', 'quaerat', '', '', '1-777-000-6054x9326', '', 0, '2010-03-08 20:46:22'),
(78, '', 'Geovany', 'Little', 'aliquid', '', 'Et non temporibus quo animi et minus qui. Sit est sit labore. Illo dolorum et omnis ullam in neque.', '318-210-0786x56268', 'pward@example.org', 'qui', '', '', '1-088-054-2892x31536', '', 0, '2001-08-08 13:22:38'),
(79, '', 'Leopold', 'Brown', 'enim', '', 'Hic tempore eius occaecati in et qui ratione. Explicabo atque tenetur dolores et qui. Consequatur se', '(046)223-4145x3996', 'ujacobi@example.org', 'et', '', '', '+41(9)1588656615', '', 0, '1981-08-27 10:35:32'),
(80, '', 'Monica', 'Rice', 'illo', '', 'Accusamus mollitia optio aliquid et repudiandae in. Debitis voluptas architecto incidunt ea eius sed', '702-292-5717x0893', 'lonie88@example.com', 'totam', '', '', '01001273652', '', 0, '1979-06-14 19:47:16'),
(81, '', 'Nathen', 'Baumbach', 'aperiam', '', 'Aut quibusdam quis molestiae. Harum inventore ullam fuga consectetur. Qui sint dolores in possimus n', '(392)806-0933x9975', 'marquardt.antonette@example.org', 'cupiditate', '', '', '(153)365-5338x2011', '', 0, '2019-03-18 00:02:50'),
(82, '', 'Hailee', 'Ebert', 'ut', '', 'Cum dolore voluptatibus aut. Eveniet delectus voluptatem magnam velit hic. Hic occaecati soluta sunt', '470.618.8346x0859', 'jaren28@example.org', 'ut', '', '', '338.791.9855', '', 0, '1996-06-05 20:06:46'),
(83, '', 'Trevor', 'Mosciski', 'quia', '', 'A enim rerum deserunt eum dolores ullam. Suscipit consequatur quis ut fugit repellendus. Quia aliqua', '248.148.7944', 'carlotta.gorczany@example.org', 'officiis', '', '', '(464)611-0021x049', '', 0, '2006-09-26 19:58:15'),
(84, '', 'Orval', 'Wehner', 'repellendus', '', 'Doloremque repudiandae repudiandae et ab. Et minima voluptas vitae ut. Veritatis ratione tenetur mol', '(520)559-7255x77092', 'otho16@example.org', 'a', '', '', '(668)849-2761', '', 0, '2017-07-03 01:14:08'),
(85, '', 'Chanel', 'Schuppe', 'minima', '', 'Vel voluptatem nulla ullam ducimus distinctio inventore laudantium. Id maiores labore aut deserunt f', '+22(0)6668260413', 'hermiston.rita@example.com', 'eos', '', '', '1-539-761-2103', '', 0, '1995-01-13 04:21:40'),
(86, '', 'Macey', 'Turner', 'soluta', '', 'Cupiditate amet tempore et aliquam necessitatibus unde recusandae. Perferendis maxime quo sit enim. ', '1-579-046-1458x98734', 'deichmann@example.com', 'qui', '', '', '(619)278-6406x72571', '', 0, '1996-10-17 07:26:45'),
(87, '', 'Everett', 'Bogan', 'distinctio', '', 'Tenetur sint quos doloribus maiores consequatur blanditiis reiciendis modi. Omnis ea labore sed dolo', '05815185966', 'hollie.windler@example.org', 'dolor', '', '', '00543123292', '', 0, '1973-08-30 14:58:09'),
(88, '', 'Delbert', 'Bahringer', 'eum', '', 'Veritatis et eligendi quo libero. Accusamus quia officia aut sunt mollitia. Non eos quia sit.', '+69(4)6132377493', 'filiberto36@example.net', 'consequatur', '', '', '563-622-9314', '', 0, '1971-08-25 21:00:00'),
(89, '', 'Stuart', 'Torp', 'ea', '', 'Quia voluptates et quia molestias provident. Suscipit qui non eos tenetur aliquam quis temporibus su', '+99(4)5952910075', 'hnienow@example.com', 'nisi', '', '', '749.693.6418x18029', '', 0, '1998-09-18 01:12:46'),
(90, '', 'Brown', 'Weissnat', 'omnis', '', 'Sunt odit omnis sint repellat consequatur sit voluptatum nisi. Voluptates qui delectus vero eum. Dol', '200-586-3686', 'irwin.strosin@example.net', 'tenetur', '', '', '592-682-7013', '', 0, '1983-08-21 08:54:32'),
(91, '', 'Bart', 'Klein', 'quis', '', 'Maiores totam eaque autem laboriosam molestias similique. Iste velit eum magni. Iure repellat omnis ', '1-770-835-1224x0969', 'reichel.cameron@example.com', 'fugiat', '', '', '+84(8)1278110711', '', 0, '1973-12-15 13:18:04'),
(92, '', 'Bridie', 'Sawayn', 'est', '', 'Saepe amet numquam in soluta iste nemo. Amet aliquam debitis delectus deserunt sed laboriosam conseq', '(166)333-8095x8529', 'chanelle.skiles@example.net', 'eaque', '', '', '974.597.7852', '', 0, '2003-12-12 20:51:00'),
(93, '', 'Ardella', 'Grady', 'nobis', '', 'Odit voluptates aut consequuntur pariatur earum. Iusto corporis quia blanditiis. Aut quidem magni en', '187-627-6135', 'tre23@example.com', 'veritatis', '', '', '(483)936-4843', '', 0, '2002-08-13 07:45:04'),
(94, '', 'Nelson', 'Heathcote', 'explicabo', '', 'Repellat qui minus ab vitae ab. Dolores omnis cupiditate sit et id ducimus. Accusamus sunt alias eni', '502.587.5955x8558', 'pfeffer.titus@example.org', 'aspernatur', '', '', '+71(4)9542400714', '', 0, '2004-05-29 07:38:53'),
(95, '', 'Lorine', 'Kiehn', 'consequatur', '', 'Voluptatibus quis ab voluptates esse voluptatem. Itaque fuga et ut eum. Qui est aliquid ex nam maxim', '1-774-577-5737x151', 'muller.rowland@example.com', 'consequatur', '', '', '681.902.4608x785', '', 0, '1980-07-30 03:46:28'),
(96, '', 'Ronny', 'Lehner', 'eveniet', '', 'Explicabo recusandae perspiciatis enim dolorem. Laborum autem rerum et perspiciatis. Rem amet volupt', '743-668-7365', 'xpfeffer@example.org', 'pariatur', '', '', '645-325-1317x56014', '', 1, '2020-10-13 10:26:50'),
(97, '', 'Garnett', 'Reinger', 'quo', '', '', '+00(0)8986750881', 'deja.farrell@example.net', 'Musa', 'Bauchi', 'Bauchi', '819-443-2824x82902', 'Father', 0, '2020-08-20 10:15:54'),
(98, '456547567', 'Mozelle', 'Hassan', 'eum', 'Male', 'Married', '(712)763-3940', 'reuben56@example.net', 'dsfgdfg', 'asgdfgsgf', 'sdfagsdfgs', '1-641-162-7349', 'Son', 0, '2020-07-28 11:46:17'),
(99, '123456', 'Abubakar', 'Ahmad', 'Yusuf', 'Male', 'Single', '08032343030', 'melyssa58@example.net', 'Ahmadu Yusuf', 'Dass Road Bauchi', 'Federal Polytechnic Bauchi', '306.844.8704x311', 'Father', 1, '2020-10-13 10:25:59'),
(100, '3445654', 'Aminu', 'Grimes', 'facilis', 'Male', 'Married', '727-303-7820x4360', 'rahul.hahn@example.com', 'dfgsdfg', 'dsfgsdgf', 'asdfsdfgsdf', '(713)537-5421', 'Naighbour', 1, '2020-10-13 10:26:45'),
(101, 'ss3455', 'Zaharadden', 'Bala', 'Nasir', 'Male', 'Married', '08147588974', '', 'sfgdfhgfh', 'sgsfddghgf', 'sfdhdfhgfhg', '', 'Mother', 1, '2020-07-28 11:48:06'),
(102, '533434', 'Hassan', 'Mohammed', 'Mayana', 'Male', 'Single', '8032547896', '', 'Abdullahi Musa', 'Gwallameji', 'Accountancy Department Federal Polytechnic Bauchi', '', 'Brother', 1, '2020-08-20 09:51:54'),
(103, '245565', 'Zaharadin', 'Bala', 'Nasir', 'Male', 'Married', '08147588974', '', 'Musa Nasir', 'Gwallameji', 'ICT/MIS', '', 'Brother', 1, '2020-08-27 15:55:01'),
(104, '484757', 'Abubakar', 'S', 'Hamza', 'Male', 'Single', '08025569874', '', 'Ahmad S Hamza', 'Gombe', 'Gwallameji', '', 'Brother', 0, '2020-10-13 10:27:02'),
(105, 'bh48447', 'Mustapha ', 'Muhammed', '', 'Male', 'Married', '0803837473', '', 'Musa Muhammed', 'Bauchi', 'Bauchi', '', 'Son', 1, '2020-10-14 13:33:06'),
(106, '37464', 'Jonha', 'Billy', 'Hatman', 'Male', 'Single', '0704948474', '', 'Nuhu Jonha', 'Yelwa', 'Poly', '', 'Mother', 0, '2020-10-15 07:17:28'),
(107, '4747', 'Aliyu', 'Usman', 'Bilya', 'Male', 'Single', '4747464543', '', '', 'Bauchi', 'Federal Polytechnic Bauchi', '', 'Brother', 1, '2020-11-09 18:01:02'),
(108, '37474', 'Rabiu', 'Musa', 'kano', 'Male', 'Single', '38384774762', '', 'Hassan Musa', 'Kano', 'Gombe State Nigeria', '', 'Cousin', 1, '2020-11-09 17:58:55'),
(109, '123456', 'Abdullahi', 'Ahmad', 'Muktar', 'Male', 'Married', '070958844', '', 'Hafsat Muktar', 'Jahun', 'Jahun', '', 'Sister', 1, '2020-11-09 18:02:20');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `unit_price` int(100) NOT NULL,
  `category_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `unit_price`, `category_id`) VALUES
(18, 'Carpet', 15000, 7),
(19, 'Bed', 40000, 7),
(20, 'G/Oil', 3000, 5);

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`id`, `category_name`) VALUES
(3, 'Electronics'),
(4, 'Building Material'),
(5, 'Farm Product'),
(7, 'Furnitures'),
(11, 'Beverages'),
(14, 'Food');

-- --------------------------------------------------------

--
-- Table structure for table `profit`
--

CREATE TABLE `profit` (
  `id` int(10) NOT NULL,
  `members_contrubution_amount` varchar(100) NOT NULL,
  `profit_month` varchar(100) NOT NULL,
  `profit_amount` varchar(100) NOT NULL,
  `date_profit` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profit`
--

INSERT INTO `profit` (`id`, `members_contrubution_amount`, `profit_month`, `profit_amount`, `date_profit`) VALUES
(1, '9', '2', '25.00', '2020-02-18'),
(3, '5000.00', '2020-09', '100000', '0000-00-00'),
(4, '59000.00', '2020-10', '20000', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `id` int(10) NOT NULL,
  `users_id` int(10) NOT NULL,
  `subject` varchar(127) NOT NULL,
  `description` text NOT NULL,
  `debit` decimal(10,2) NOT NULL,
  `credit` decimal(10,2) NOT NULL,
  `date_trans` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`id`, `users_id`, `subject`, `description`, `debit`, `credit`, `date_trans`) VALUES
(1, 9, '23232', '32323', '2323.00', '2323.00', '2017-07-21 00:00:00'),
(2, 9, '', 'Test Investment', '0.00', '100.00', '2017-07-30 18:46:17'),
(3, 9, 'Test', 'Test Investment', '0.00', '100.00', '2017-07-30 18:48:38'),
(4, 9, 'Test2', '5rrte frererw', '0.00', '33.00', '2017-07-30 19:02:28'),
(5, 9, 'Test2', '5rrte frererw', '0.00', '230.00', '2020-02-18 05:55:22');

-- --------------------------------------------------------

--
-- Table structure for table `widthdraw`
--

CREATE TABLE `widthdraw` (
  `id` int(10) NOT NULL,
  `users_id` int(10) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `date_withdraw` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `widthdraw`
--

INSERT INTO `widthdraw` (`id`, `users_id`, `amount`, `date_withdraw`) VALUES
(1, 9, '25.00', '2020-02-18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_tracker`
--
ALTER TABLE `activity_tracker`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adminusers`
--
ALTER TABLE `adminusers`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `bankinfo`
--
ALTER TABLE `bankinfo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`);

--
-- Indexes for table `commodities_loan`
--
ALTER TABLE `commodities_loan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deposit`
--
ALTER TABLE `deposit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loan`
--
ALTER TABLE `loan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profit`
--
ALTER TABLE `profit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `widthdraw`
--
ALTER TABLE `widthdraw`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_tracker`
--
ALTER TABLE `activity_tracker`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `adminusers`
--
ALTER TABLE `adminusers`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bankinfo`
--
ALTER TABLE `bankinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `commodities_loan`
--
ALTER TABLE `commodities_loan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `deposit`
--
ALTER TABLE `deposit`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `loan`
--
ALTER TABLE `loan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `profit`
--
ALTER TABLE `profit`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `widthdraw`
--
ALTER TABLE `widthdraw`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
