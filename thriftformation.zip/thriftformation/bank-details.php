<?php
	session_start();
	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
			header('location:index.php');
	}
?>
<!Doctype html>
<html lang="en">
  <?php include_once ('template/head.php')?>
	<body>
		<?php include_once('template/header.php');?>
		<br/>
			<div class="container">
				<div class="row">
					<div class=" col-sm-8" style="border-top: 0px;">
						<div class="row">
							<div class="col-sm-12">
								<br/>
									<div class="card">
										<div class="card-header" style="background: #F0F0F0;">
											<center><h5>LOAN PAY-INFORMATIONS</h5></center>
										</div>
											<div class="card-body">
												<center><h5 class="card-title">BANK INFORMATIONS </h5></center>
								
													<label> Bank Name</label>
													<div class="form-group"> 
														<input type="text" class="form-control" placeholder="Bank Name">
													</div>
								
													<label>Account Number</label>
													<div class="form-group"> 
														<input type="text" class="form-control" placeholder="Account Number">
													</div>
			
													<label> Account Name</label>
													<div class="form-group"> 
														<input type="text" class="form-control" placeholder="Account Name">
													</div>
		 
													<label>Booklet Number </label>
													<div class="form-group"> 
														<input type="text" class="form-control" placeholder="Booklet Number">
													</div>
														<div class="card">
															<div class="card-body">
																<center><h5>DEPOSIT/WITHDRAWAL</h5></center>
																	<div class="form-group">
																		<label for="exampleFormControlSelect1">Bank Name</label>
																		<select class="form-control" id="exampleFormControlSelect1">
																			<option selected>--Select--</option>
																			<option>Access Bank</option>
																			<option>Guaranty Trust Bank (GTB)</option>
																			<option>Union Bank</option>
																			<option>First Bank</option>
																			<option>Polaris Bank</option>
																			<option>Eco Bank</option>
																			<option>Wema Bank</option>
																			<option>United Bank for Africa (UBA)</option>
																			<option>Starling Bank</option>
																			<option>Firt City Monument Bank (FCMB)</option>
																			<option>Platinum Habib Bank (BANK PHB)</option>
																			<option>Heritage Bank</option>
																			<option>Zineth Bank</option>
																			<option>Unity Bank</option>
																			<option>Others</option>
																		</select>
																	</div>
																	
																		<label> Account Number</label>
																		<div class="form-group"> 
																			<input type="text" class="form-control" placeholder="Account Number">
																		</div>
																		
																	<div class="form-group">
																		<label for="exampleFormControlSelect1">Operations</label>
																		<select class="form-control" id="exampleFormControlSelect1">
																			<option selected>--Select--</option>
																			<option>Depositing</option>
																			<option>Withdrawal</option>
																			<option>Transfer</option>
																			<option>Others</option>
																		</select>
																	</div>	
																	
																		<label>Reference Number</label>
																		<div class="form-group"> 
																			<input type="text" class="form-control" placeholder="Reference Number">
																		</div>
																		
																		<label>Amount</label>
																		<div class="form-group"> 
																			<input type="text" class="form-control" placeholder="Amount">
																		</div>
																		
																	<div class="form-group">
																		<label for="exampleFormControlSelect1"> Transaction Date </label>
																		<input type= "date" class="form-control"> 
																	</div>	
															</div>
														</div>	
											</div>
										<hr/>
										<div class="col-sm-12" >
											<div class="card" style="min-height: 400px; margin: 0px;">
												<div class="card-body">
													<center><h5 class="card-title">LIST OF BANK TRANSACTIONS</h5></center>
														<table class="table table-bordered table-striped">
															<tr>
																<th>Bank Name</th>
																<th>Account No.</th>
																<th>Transaction</th>
																<th>ID</th>
																<th>Amount</th>
																<th>Date</th>
															</tr>
															<tr>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
															</tr>
															<tr>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
															</tr>
															<tr>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
															</tr>
															<tr>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
															</tr>
															<tr>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
																<td>Data</td>
															</tr>
															
														</table>
												</div>
											</div>
										</div>											
									</div>
							</div>
								
								
								
									
									
						</div>
					</div>
						<?php include_once('template/menu.php');?>
				</div>
			</div>
		<footer class="footer mt-auto py-3"  style="background: #F0F0F0;">
			<div class="container">
				<center><p class="text-muted">Copyright &copy; 2020: All Rights</p></center>
			</div>
		</footer>
	</body>
</html>