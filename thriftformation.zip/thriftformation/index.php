<?php
	session_start();
?>
<!doctype html>
<html lang="en">
 <?php include_once ('template/head.php')?>


<body>
<?php //include_once('template/header.php')?>
<div class="container">
  <div class="row">
    <div class="col-sm">
      
    </div>
    <div class="col-sm">
    	<br>
    	<br>
    	<br>
		<form id="login_form" action="checklogin.php" method="post" onsubmit="return do_login();">
			<div class="card" style="margin-top: 20px;">
				<div class="card card-headers">
					<center><h5><div style="background-color:#F0F0F0;padding:10px 5px;">BSHK Cooperative Society</div></h5></center>
						<div class="card-body animate__animated animate__zoomIn">
							<div class="form-group">
								 <center><img src="images/hadakai.png" class="d-inline-block align-top" alt=""></center>
							</div>
							<div class="form-group inner-addon left-addon">

								<input type="text" name="username" autocomplete="off" id="username" class="form-control" placeholder="Username...">
								
							</div>
							
							<div class="form-group inner-addon left-addon">
								<input type="password" name="password" id="password" class="form-control" placeholder="Password...">
								<!-- <i class="fa fa-key"></i> -->
							</div>
							<div class="form-group form-check">
								<input type="checkbox" class="form-check-input" id="exampleCheck1">
								<label class="form-check-label" for="exampleCheck1">Remember me</label>
							</div>
							<div class="form-group">
								<button class="btn btn-primary btn-block" name="btnLogin"><i class="fa fa-sign-in"></i> Login</button>
							</div>
							<div class="form-group">
								<center><p id="loading_spinner"><img src="images/loader.gif" height="40" width="40"></p></center>
								<center><div id="error"></div></center>
							</div>
						</div>
			
				</div>
			</div>
		</form>
		<hr>
		<center><small><p class="text-muted">Copyright &copy; <?php echo date('Y')?> All rights reserved MIS/ICT FPTB </p></small></center>
      </div>
		<div class="col-sm">
		</div>
  </div>
</div>
	
		<?php include_once('scripts/javascript.php')?>
		<script type="text/javascript">
				function do_login()
				{
				 var username=$("#username").val();
				 var password=$("#password").val();
				 if(username!="" && password!="")
				 {
				  $("#loading_spinner").css({"display":"block"});
				  $.ajax
				  ({
				  type:'post',
				  url:'checklogin.php',
				  data:{
				   btnLogin:"btnLogin",
				   username:username,
				   password:password
				  },
				  success:function(response) {
				  if(response=="success")
				  {
					//window.location.href="dashboard.php";
					$("#error").css({"display":"none"});
					setTimeout('window.location.href ="dashboard.php"; ',3000);
				  }
				  else
				  {
					$("#loading_spinner").css({"display":"none"});
					//alert("Wrong Details");
					$("#error").html('<div class="alert alert-danger"><small>Login fail,Please verify your userid or password</small></div>');
				  }
				  }
				  });
				 }

				 else
				 {
				  //alert("Please Fill All The Details");
				  $("#error").html('<div class="alert alert-danger"><small>Please enter username and password</small></div>');
				 }

				 return false;
				}
		</script>
</body>
</html>