<!-- Modal -->
<div class="modal pay-loan-modal animate__animated animate__zoomIn" id="PayLoanModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl ">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">LOAN REPAYMENT FORM</h5>
                <button type="button" id="PayLoan" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
        <form name="LoanPaymentForm" id="LoanPaymentForm" method="post">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="card">
                         <div class="card-body">
                           <!-- <label><strong>Name of Member</strong></label> -->
                          <div class="form-group"> 
                            <!-- <p id="member_name"></p> -->
                            <input type="hidden" name="member_name" id="member_name">
                          </div>
                    
                      <label> <strong>Amount Recieved (Loan)</strong> </label>
                      <div class="form-group"> 
                        <p id="amt_recieved"></p>
                        
                      </div>
                      <label> <strong>Date Recieved </strong></label>
                      <div class="form-group">
                       <p id="date_collected"></p>
                        <label> <strong>Percentage Deducted (%) </strong></label>
                          <div class="form-group">
                           <p id="interest_on_loan"></p>
                          </div>

                        <label> <strong>Loan Interest Deducted </strong></label>
                          <div class="form-group">
                          <!--  <p id="loan_interest_amt"></p> -->
                          </div>
                      </div>
                     
                         </div>
                      </div>
                     
                    </div>
                    <div class="col-md-6">
                      <div class="card">
                         <div class="card-body">
                          
                         <label> <strong>Total Amount Expected </strong></label>
                          <div class="form-group">
                           <!-- <p id="exp_paybackamt"></p> -->
                           <input type="text" name="exp_paybackamt" class="form-control" id="exp_paybackamt" readonly="readonly">
                          </div>
                        
                          <label> <strong>Amount Paid Back</strong></label>
                          <div class="form-group">
                           <input type="text" class="form-control" oninput="loanBalance(this.value);" name="amt_paid" id="amt_paid"  autocomplete="off">
                          </div>

                          <label> <strong>10% Interest Charges</strong></label>
                          <div class="form-group">
                           <input type="text" class="form-control" name="amt_paid" id="loan_interest_amt" readonly="readonly" autocomplete="off">
                          </div>

                          <label> <strong>Month of Payment</strong></label>
                          <div class="form-group">
                           <input type="date" class="form-control" name="pay_month" id="pay_month"  autocomplete="off">
                          </div>

                          <label> <strong>New Balance </strong></label>
                          <div class="form-group">
                           <input type="text" class="form-control" name="new_balance" id="new_balance" readonly="readonly">
                          </div>
                         
                          <div class="form-group">
                        <input type="submit" value="Pay Loan" name="btnPayLoan" id="btnPayLoan" class="btn btn-primary btn-block">
                      </div>

                    </div>
                   </div>
                </div>
                </div>   
               </form>
            </div>
            
            <div class="modal-footer">
                <input type="hidden" name="member_id" id="member_id" />
                <center><small>Copyright &copy; <?php echo date('Y');?> All rights reserved <strong>BSHK Cooperative Society</strong></small></center>
               
            </div>
        
        </div>
    </div>
</div>
<script type="text/javascript">
function loanBalance(input) {
    input = parseInt(input);
    var amt_expected = document.LoanPaymentForm.exp_paybackamt.value;
    var amt_paid = document.LoanPaymentForm.amt_paid.value;
    var loan_interest_amt = document.LoanPaymentForm.loan_interest_amt.value;
    var new_balance = document.LoanPaymentForm.new_balance.value;
    if (!isNaN(new_balance) && (new_balance != Number.POSITIVE_INFINITY) && (new_balance != Number.NEGATIVE_INFINITY)) {
         input = input || 0;
        document.LoanPaymentForm.new_balance.value = Number(amt_expected) - Number(loan_interest_amt) - Number(input);
    }else {
        //document.LoanPaymentForm.paytotal.value = "";
        //input = input || 0;
        document.LoanPaymentForm.new_balance.value = "";
    }
}
</script>
<script type="text/javascript">
  function calculateDue(input) {
  input = parseInt(input); // State that the input received is a number
  // Without the parsing, the addition would be *appended* to the input value
  input += input / 10; // Add 10% of input to itself
  input = input || 0;
  document.getElementById('amt_due').value = input; // Output the result
  //document.getElementsByTagName('span')[0].innerHTML = input; // Output the result
  loanBalance();
}
</script>
