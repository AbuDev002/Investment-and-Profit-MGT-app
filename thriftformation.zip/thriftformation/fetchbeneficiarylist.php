 <?php
function formatMoney($number, $fractional=false) {
    if ($fractional) {
        $number = sprintf('%.2f', $number);
    }
    while (true) {
        $replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
        if ($replaced != $number) {
            $number = $replaced;
        } else {
            break;
        }
    }
    return $number;
}
//this function get you the percentage of a number
function get_percentage($total, $number)
{
  if ( $total > 0 ) {
   return round($number / ($total / 100),2);
    //$member_percentage = $number / ($total / 100);
    //return $member_percentage;
  } else {
    return 0;
  }
}
?>
<?php
$i = 0; 
include_once('connection.php'); 
//if(!isset($_GET['q'])){
$query = "SELECT * FROM deposit WHERE date_deposit='".$_GET['q']."' ORDER BY id DESC";  
$result = mysqli_query($connect, $query);
if($rs = mysqli_num_rows($result) >0){  
while($row = mysqli_fetch_array($result))  
{  
$i++;
?> 
<tr>  
    <td><?php echo $i;?></td>  
    <td>
      <?php 
      $getusername = mysqli_query($connect,"select * from members where id='".$row["users_id"]."'");
        $name = mysqli_fetch_array($getusername);
        echo $name['surname']." ".$name['firstname']." ".$name['othername'];
      ?>
      <input type="hidden" name="mem_name" value="<?php echo $name['surname']." ".$name['firstname']." ".$name['othername'];?>">
    </td>  
    <td>
      <?php echo "&#8358; ".formatMoney($row["amount"], true);?>
        <input type="hidden" name="amt_cont" value="<?php echo formatMoney($row["amount"], true);?>">
      </td>  
    <td>
      <?php echo get_percentage(@$_GET['mc'], $row["amount"]);?>
      <input type="hidden" name="percent_value" id="percent_value" class="percent_value" value="<?php echo get_percentage(@$_GET['mc'], $row["amount"]);?>">
      <!-- <input type="hidden" name="" value=""> -->
    </td>
    <td id="profit_entitled" class="profit_entitled">
       <?php
        $getprofit = mysqli_query($connect,"select * from profit where profit_month='".$_GET['q']."' and members_contrubution_amount ='".$_GET['mc']."'");
          if($presult = @mysqli_num_rows($getprofit) > 0){
          $getprofresult = mysqli_fetch_array($getprofit);
          echo "&#8358; ".formatMoney(($getprofresult['profit_amount'] * get_percentage(@$_GET['mc'], $row["amount"])) / 100);
        }else{
           echo "0";
        }
       ?> 
       <input type="hidden" name="p_ent" value="<?php echo formatMoney(($getprofresult['profit_amount'] * get_percentage(@$_GET['mc'], $row["amount"])) / 100);?>">
    </td>
</tr>
<?php }?>
<tr>
  <td colspan="10" align="right"><strong>Profit Obtained:</strong> &#8358;<?php if(isset($getprofresult['profit_amount'])){ echo formatMoney($getprofresult['profit_amount']);
    //json_encode(['profit_obtained' => $getprofresult['profit_amount']]);
}else{ echo "0";}?> 
<input type="hidden" name="p_amt" value="<?php echo $getprofresult['profit_amount']?>">
</td>
</tr> 
<?php 
}else{ echo "<td colspan='6' align='center'><p>No contribution available</p></td>";}?> 