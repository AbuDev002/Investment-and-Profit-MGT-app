<?php
session_start();
if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
header('location:index.php');
}
?>
<!doctype html>
<html lang="en">
<?php include_once ('template/head.php')?>
<body>
<?php include_once('template/header.php');?>
<br/>
<div class="container">
<div class="row">
<div class="col-md-9">
		<div class="card">
			<div class="card-header">
				<center><h5>GENERATING AND PRINTING OF REPORTS</h5></center>
			</div>
		<div class="card-body">
			<div class="row">
				<div class="col-md-4">
			<div class="list-group">
				  <button type="button" class="list-group-item list-group-item-action active" aria-current="true">
				    Reports
				  </button>
				  <button type="button" class="list-group-item list-group-item-action" id="btnCommodity" onclick="getCommoditysummary()">Commodity Loan</button>
				  <button type="button" class="list-group-item list-group-item-action" id="btnCashLoan" onclick="getCashLoanSummary()">Cash Loan</button>
				  <button type="button" class="list-group-item list-group-item-action" onclick="getContributionsSummary()">Contributions</button>
				 <!--  <button type="button" class="list-group-item list-group-item-action" disabled>Shared Profit</button> -->
			</div>
				</div>
				<div class="col-md-8">
					<fieldset class="scheduler-border" id="operation_menu" style="height:100%;">
						<legend class="scheduler-border" id="scheduler-border"><strong>Report Summary</strong></legend>
						<!--Commodity Loan Report Summary-->
						<div class="card animate__animated animate__zoomIn" id="commodity_summary" style="width: 100%;border:0px;display:none;">
						  <div class="card-body">
						   	<?php
						   		include_once('connection.php');
						   		 function formatMoney($number, $fractional=false) {
								    if ($fractional) {
								        $number = sprintf('%.2f', $number);
								    }
								    while (true) {
								        $replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
								        if ($replaced != $number) {
								            $number = $replaced;
								        } else {
								            break;
								        }
								    }
								    return $number;
								} 
						   		//getting number of active loan
						   		$get_activeloan = mysqli_query($connect,"select count(*) as alcount from commodities_loan where loan_status= 0");
						   		$activeloan_list = mysqli_fetch_array($get_activeloan);
						   		//getting number of paid loan
						   		$get_paidloan = mysqli_query($connect,"select count(*) as plcount from commodities_loan where loan_status= 1");
						   		$paidloan_list = mysqli_fetch_array($get_paidloan);
						   		//getting total amount issued for loan
						   		$get_amountissued = mysqli_query($connect,"select sum(percent_charges) as amtissued from commodities_loan");
						   		$amountissued_list = mysqli_fetch_array($get_amountissued);
						   	?>
						    <p><strong>Unpaid Loan:</strong> <?php echo $activeloan_list['alcount'];?></p>
						    <p><strong>Paid Loan:</strong> <?php echo $paidloan_list['plcount'];?></p>
						    <p><strong>Total Amount Unpaid:</strong> &#8358;  <?php echo formatMoney($amountissued_list['amtissued'],true);?></p>
						    <!-- <p><strong>Total Amount pending:</strong></p> -->
						  </div>
						  <form action="get_monthly_commodity_loan.php" method="get">
							  <div class="card-footer">
							   	 	<div class="row">
							   	 		<div class="col-md-6">
							   	 			<input type="date" name="loan_date" class="form-control">
							   	 		</div>
							   	 		<div class="col-md-4">
							   	 			<button class="btn btn-primary btn-block">Get report</button>
							   	 		</div>
							   	 		<div class="col-md-2">
							   	 			<a href="commodity_loan_report.php" class="btn btn-primary btn-block">All</a>
							   	 		</div>
							   	 	</div>
							   </div>
						   </form>
						</div>
						<!--Cash Loan Report Summary-->
						<div class="card animate__animated animate__zoomIn" id="cashloan_summary" style="width: 100%;border:0px;display:none;">
						  <div class="card-body">
						   	<?php
						   		//getting number of active loan
						   		$get_activecloan = mysqli_query($connect,"select count(*) as alcount from loan where loan_status= 0");
						   		$activecloan_list = mysqli_fetch_array($get_activecloan);
						   		//getting number of paid loan
						   		$get_paidcloan = mysqli_query($connect,"select count(*) as plcount from loan where loan_status= 1");
						   		$paidcloan_list = mysqli_fetch_array($get_paidcloan);
						   		//getting total amount issued for loan
						   		$get_camountissued = mysqli_query($connect,"select sum(exp_amt) as amtissued from loan");
						   		$camountissued_list = mysqli_fetch_array($get_camountissued);
						   	?>
						    <p><strong>Unpaid Cash Loan:</strong> <?php echo $activecloan_list['alcount']?></p>
						    <p><strong>Paid Cash Loan:</strong> <?php echo $paidcloan_list['plcount'];?></p>
						    <p><strong>Total Amount Unpaid:</strong> &#8358;  <?php echo formatMoney($camountissued_list['amtissued'],true);?></p>
						   <!--  <p><strong>Total Amount pending:</strong></p> -->
						  </div>
						  <form action="get_monthly_cash_loan.php" method="get">
						   <div class="card-footer">
						   	 	<div class="row">
						   	 		<div class="col-md-6">
						   	 			<input type="date" name="loan_date" class="form-control">
						   	 		</div>
						   	 		<div class="col-md-4">
						   	 			<button class="btn btn-primary btn-block">Get report</button>
						   	 		</div>
						   	 		<div class="col-md-2">
						   	 			<a href="cash_loan_report.php" class="btn btn-primary">All</a>
						   	 		</div>
						   	 	</div>
						   </div>
						</form>
						</div>

						<!--Contrubutions Report-->
						<div class="card animate__animated animate__zoomIn" id="contributions_summary" style="width: 100%;border:0px;display:none;">
						  <div class="card-body">
						   	<table class="table table-bordered">
						   		<tr>
						   			<td><strong>Year/Month</strong></td>
						   			<td><strong>Total Contribution</strong></td>
						   		</tr>
						   		<?php
						   			include_once('connection.php'); 
									 $query = mysqli_query($connect,"SELECT * FROM deposit ORDER BY date_deposit DESC LIMIT 3");  
									 while($result = mysqli_fetch_array($query)){ 
						   		?>
						   		<tr>
						   			<td>
						   				<?php 
						   				echo date("F-Y", strtotime($result['date_deposit']));
						   				?>
						   					
						   				</td>
						   			<td><?php echo $result['amount'];?></td>
						   		</tr>
						   	<?php } ?>
						   	</table>
						    
						  </div>
						  <a href="contributions_report.php" class="btn btn-primary btn-block">Get Complete Report</a>
						</div>
					</fieldset>
				</div>
			</div>
		</div>
		</div>
	</div>
<?php include_once('template/menu.php');?>
</div>	
</div>
<!--</div>-->

<?php include_once('template/footer.php');?>
<?php include_once('modals/commodities/add_new_commodity.php')?>
<?php include_once('modals/commodities/request_commodity_loan.php')?>
<?php include_once('modals/commodities/add_category.php')?>
<?php include_once('scripts/javascript.php')?>
<script src="js/bootstrap-select.min.js"></script>
<script type="text/javascript">
	 $(".modal").modal({
        show: false,
        backdrop: 'static'
    });  
</script>
<script type="text/javascript">
  $(document).ready(function(){
    $('.selectpicker').selectpicker();
  })

  // $("#btnCommodity").onclick(function(){
  //   $('#commodity_summary').style("display","block");
  // })
</script>
<script type="text/javascript">
	function getCommoditysummary() {
	  document.getElementById("commodity_summary").style.display = "block";
	  document.getElementById("cashloan_summary").style.display = "none";
	  document.getElementById("contributions_summary").style.display = "none";
	  document.getElementById("scheduler-border").innerHTML  = "<strong>Commodity Loans Summary</strong>";

	}
	function getCashLoanSummary() {
	  document.getElementById("cashloan_summary").style.display = "block";
	  document.getElementById("commodity_summary").style.display = "none";
	  document.getElementById("contributions_summary").style.display = "none";
	  document.getElementById("scheduler-border").innerHTML  = "<strong> Cash Loans Summary</strong>";
	}
	function getContributionsSummary() {
	  document.getElementById("cashloan_summary").style.display = "none";
	  document.getElementById("commodity_summary").style.display = "none";
	  document.getElementById("contributions_summary").style.display = "block";
	  document.getElementById("scheduler-border").innerHTML  = "<strong> Contribution Report</strong>";
	}
</script>
</body>
</html>