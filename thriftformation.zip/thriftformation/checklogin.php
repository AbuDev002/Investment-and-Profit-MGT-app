<?php 
		session_start();
		if(isset($_POST['btnLogin'])){
			
			$username = $_POST['username'];
			$password = $_POST['password'];
			$pass_hash = md5($password);
			include_once('connection.php');
			$query=mysqli_query($connect,"SELECT * FROM `adminusers` WHERE username = '$username' AND password='$pass_hash'") or die('query failed');
			if($result=mysqli_fetch_array($query)){ 
				$_SESSION['userid']= $result['userid'];
				$_SESSION['name']= $result['name'];
				$_SESSION['username']= $result['username'];
				$_SESSION['password']= $result['password'];
				//track user login
				$track_qr = mysqli_query($connect,"INSERT INTO activity_tracker (activity_descrip,user_id) VALUES('Login to the system','".$result['userid']."')");
				echo "success";
			}else{
				echo "fail";
			}
			exit();
		}
?>