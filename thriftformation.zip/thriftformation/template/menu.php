<div class="col-md-3">

	
	<div class="row">
		<div class="col-sm-8"></div>
		<div class="col-sm-4" style="text-align: right;"> <!-- <a href="logout.php" ><i class="fa fa-sign-out"></i>Logout</a> --></div>
	</div>
	<fieldset class="scheduler-border" id="operation_menu">
		<legend class="scheduler-border"><strong>Operational Menu</strong></legend>
		<ul class="list-group list-group-flush">
			<li class="list-group-item"><a href="dashboard.php"> <i class="fa fa-home"></i>  Dashboard</a></li>
			<li class="list-group-item"><a href="membership-active.php"> <i class="fa fa-users"></i> Membership</a></li>
			<li class="list-group-item"><a href="membership-contribution.php"><i class="fa fa-user-plus"></i> Contributions</a></li>
			<li class="list-group-item"><a href="manage-profit.php"><i class="fa fa-money"></i> Manage Profit</a></li>
			<li class="list-group-item"><a href="loan.php"><i class="fa fa-money"></i> Manage Loan</a></li>
			<li class="list-group-item"><a href="commodities.php"><i class="fa fa-product-hunt"></i> Manage Comodities</a></li>
			<li class="list-group-item"><a href="reports.php"><i class="fa fa-file"></i> Reports</a></li>
			<li class="list-group-item"><a href="logout.php" ><i class="fa fa-sign-out"></i>Sign Out</a></li>
	</ul>
	</fieldset>
</div>