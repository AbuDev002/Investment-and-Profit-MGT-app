 <head>
  <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> IPT-Software </title>
	 <!-- Bootstrap CSS -->
    <!--<link rel="stylesheet" href="css/bootstrap.min.css">-->
	<link rel="stylesheet" href="css/bootstrap.min.css">
  
  <link href="css/dataTables.bootstrap4.min.css" rel="stylesheet">
  <link href="css/responsive.bootstrap4.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/jquery-ui.css">
  <!-- <link rel="stylesheet" type="text/css" href="css/datatable.min.css"> -->
  <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
  <link rel="shortcut icon" type="text/css" href="images/favicon.jpg">
  <!-- include the style -->
<link rel="stylesheet" href="css/alertify.min.css" />
<link rel="stylesheet" href="css/animate.css" />
<!-- include a theme -->
<link rel="stylesheet" href="css/themes/default.min.css" />
  <link href="css/bootstrap-select.min.css" rel="stylesheet">
  
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <style>
    .bs-example{
      margin: 20px;
    }
    @media screen and (min-width: 768px) {
        .modal-dialog {
          width: 700px; /* New width for default modal */
        }
        .modal-sm {
          width: 350px; /* New width for small modal */
        }
    }
    @media screen and (min-width: 992px) {
        .modal-lg {
          width: 950px; /* New width for large modal */
        }
    }
</style>
  <script src="https://use.fontawesome.com/1fcdc78ecd.js"></script>
  </head>