<footer class="footer mt-auto py-3"  style="background: #F0F0F0;">
	<div class="container">
		<small><center><p class="text-muted">Copyright &copy; <?php echo date('Y');?> All rights reserved ICT/MIS FPTB</p></center></small>
	</div>
</footer>
