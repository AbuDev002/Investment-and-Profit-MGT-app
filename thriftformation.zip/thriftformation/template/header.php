<!-- Image and text -->
<nav class="navbar  navbar-custom">
  <a class="navbar-brand" href="index.php">
    <img src="images/hadakai.png" height="30" class="d-inline-block align-top" alt="" loading="lazy">
    BSHK Cooperative Society
  </a>
</nav>