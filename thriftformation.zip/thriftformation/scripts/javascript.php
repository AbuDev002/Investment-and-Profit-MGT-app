<script type="text/javascript" src="js/jquery.js"></script>
<!-- <script type="text/javascript" src="js/jquery-1.9.1.js"></script> -->
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
 <script type="text/javascript" src="js/jquery.validate.min.js"></script>
<!-- include the script -->
<script src="js/alertify.min.js"></script>
<!-- <script type="text/javascript" src="js/jquery.dataTables.js"></script> -->
<script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="js/responsive.bootstrap4.min.js"></script>
<script type="text/javascript" src="js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="js/buttons.print.min.js"></script>