<!-- Modal -->
<div class="modal add-commodity-modal animate__animated animate__zoomIn" id="AddCategoryModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">ADD NEW PRODUCT CATEGORY</h5>
                <button type="button" id="applyLoan" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            	<div class="card">
            		<div class="card-body">
            			<div class="row">
                    <div class="col-md-6">
                         <form id="addCategoryForm" name="addCategoryForm">
                            <div class="form-group">
                                <label>Category Name</label>
                                <div class="form-group">
                                    <input type="text" name="category_name" class="form-control" id="category_name" placeholder="Enter category..." autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-primary" id="btnAddCategory">Add</button>
                                </div>
                            </div>
                         </form>
                    </div>
                    <div class="col-md-6">
                        <h6>Category List</h6>
                        <ul class="list-group" id="loadProductCategory">

                         </ul>
                    </div>
               </div>
            		</div>
            	</div>
		       
        </div>
    </div>
</div>
</div>

