<!-- Modal -->
<div class="modal request-commodity-modal animate__animated animate__zoomIn" id="RequestCommodityModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">COMMODITY LOAN APPLICATION FORM</h5>
                <button type="button" id="applyLoan" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <div class="card">
	        <div class="card-body">
	        <form name="CommodityLoanForm" id="CommodityLoanForm"> 
	        <div class="row">
	        	<div class="col-md-6">
	        		<div class="form-group">
						<label>Full Name</label> 
						 <select id="selectpicker" class="form-control selectpicker" name="member_name" data-live-search="true" style="background: #fff;">
                           
                           <option value="">Choose Member</option>
                           <?php 
                              include_once('connection.php');
                              $getstafflist = mysqli_query($connect,"select * from members");
                              while($memberlist = mysqli_fetch_array($getstafflist)){
                              ?>
                                 <option value="<?php echo $memberlist['id'];?>"><?php echo $memberlist['firstname']." ".$memberlist['surname']." ".$memberlist['othername'];?></option>
                              <?php
                              }
                           ?>
                        </select>
					</div>
					
				<div class="form-group">
					<label for="exampleFormControlSelect1">Product Name</label>
					<select id="product_name" name="product_name" onchange="getProductPrice(this)" class="form-control">
            		<option disabled selected>Choose product...</option>
            				<?php 
            					include_once('connection.php');
            					$getcategories = mysqli_query($connect,"select * from products");
            					while($prodrow = mysqli_fetch_array($getcategories)){
            					?>
            					<option data-price="<?php echo $prodrow['unit_price'];?>" value="<?php echo $prodrow['id'];?>"><?php echo $prodrow['product_name'];?></option>
            				<?php } ?>
            		</select>
				</div>
				<div class="form-group">
					<label for=""> Product Price </label>
					<input type="text" name="product_price" id="price" class="form-control" readonly="readonly" autocomplete="off">
					<!-- <div id="price"></div>  -->
				</div>
	        	</div>
	        	<div class="col-md-6">
	        		<div class="form-group">
						<label for="exampleFormControlSelect1"> Date </label>
						<input type= "date" id="date_recieved" name="date_recieved" class="form-control"> 
					</div>

					<div class="form-group">
						<label for="exampleFormControlSelect1">Loan Charges</label>
							<input type="text" class="form-control" name="loan_charges" id="loan_charges"  placeholder="Loan charges" autocomplete="off">
					</div>
					<div class="form-group">
						<label for="exampleFormControlSelect1">Loan Duration (Month)</label>
						<input type="text" name="loan_duration" class="form-control" value="1" readonly="readonly">
					</div>
	        	</div>
	        	<div class="card-footer">
            		<button class="btn btn-primary btn-block" id="btnCommodityLoan"> Apply Loan</button>
            	</div> 
	        </div>
	      
	        </form>
	            	</div>
	        	</div>
        </div>
    </div>
</div>
</div>
<script type="text/javascript">
	function getProductPrice(sel) {
	  var opt = sel.options[sel.selectedIndex];
	  var price = opt.dataset.price
	  document.getElementById("price").value = price;
	}
</script>
