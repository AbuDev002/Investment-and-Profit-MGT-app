<!-- Modal -->
<div class="modal pay-commodityloan-modal animate__animated animate__zoomIn" id="PayCommodityLoanModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">PAY COMMODITY LOAN</h5>
                <button type="button" id="applyLoan" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <div class="card">
	        <div class="card-body">
	        <form name="PayCommodityLoanForm" id="PayCommodityLoanForm"> 
	        <div class="row">
	        	<div class="col-md-6">
				<div class="form-group">
					<label for="exampleFormControlSelect1">Amount Recieved</label>
					<input type="text" class="form-control" id="amount_recieved" name="amount_recieved" autocomplete="off" oninput="getRemainingBalance();">
				</div>
				<div class="form-group">
					<label for=""> Remaining Balance </label>
					<input type="text" class="form-control" id="remaining_balance" name="remaining_balance" readonly="readonly">
				</div>
				<div class="form-group">
					<button class="btn btn-primary btn-block" id="btnPayCommodityLoan"> Pay Loan</button>
				</div>
	        	</div>
	        	<div class="col-md-6" id="loadMemgberLoanDetails">

	        	
	        	</div>
	        	<!-- <div class="card-footer">
            		
            	</div>  -->
	        </div>
	      
	        </form>
	            	</div>
	        	</div>
        </div>
    </div>
</div>
</div>
<script type="text/javascript">
function getRemainingBalance() {
    var amount_recieved = document.PayCommodityLoanForm.amount_recieved.value;
    var remaining_balance = document.PayCommodityLoanForm.remaining_balance.value;
    var rembalance = document.PayCommodityLoanForm.rembalance.value;
    // Check that the result is a finite number. If so, display the results.
    if (!isNaN(amount_recieved) && 
        (amount_recieved != Number.POSITIVE_INFINITY) &&
        (amount_recieved != Number.NEGATIVE_INFINITY)) {
        document.PayCommodityLoanForm.remaining_balance.value = Number(rembalance) - Number(amount_recieved);
       // document.PayCommodityLoanForm.totalinterest.value = interest;
    }
    else {
        document.PayCommodityLoanForm.amount_recieved.value = "";
        document.PayCommodityLoanForm.remaining_balance.value = "";
    }
}

</script>
