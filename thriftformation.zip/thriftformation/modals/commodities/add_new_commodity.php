<!-- Modal -->
<div class="modal add-commodity-modal animate__animated animate__zoomIn" id="AddProductModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">ADD NEW PRODUCT</h5>
                <button type="button" id="applyLoan" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            	<div class="card">
            		<div class="card-body">
            			 <div class="row">
            			 	<div class="col-md-4">
            			 		<form id="addCommodityForm" name="addCommodityForm">
		                	<div class="form-group">
		                		<label>Product Name</label>
		                		<div class="form-group">
		                			<input type="text" name="product_name" id="product_name" class="form-control" placeholder="Enter product name...">
		                		</div>
		                		<label>Product Category</label>
		                		<div class="form-group">
		                			<select id="product_category" class="form-control" name="product_category">
		                				<option>--Select--</option>
		                				<?php 
		                					include_once('connection.php');
		                					$getcategories = mysqli_query($connect,"select * from product_category");
		                					while($catrow = mysqli_fetch_array($getcategories)){
		                					?>
		                					<option value="<?php echo $catrow['id'];?>"><?php echo $catrow['category_name'];?></option>
		                					<?php } ?>
		                			</select>
		                		</div>
		                		<label>Product Price</label>
		                		<div class="form-group">
		                			<input type="text" id="product_price" name="product_price" class="form-control" placeholder="Enter product price..." autocomplete="off">
		                		</div>
		                		<div class="form-group">
		                			<button class="btn btn-primary" name="btnAddCommodity">Add</button>
		                		</div>
		                	</div>
		        		 </form>
            			 	</div>
            			 	<div class="col-md-8">
            			 		<h6>List of Products</h6>
            			 		<hr>
            			 		<table class="table table-bordered">
            			 			<thead>
                                        <tr>
                			 				<th>Product</th>
                			 				<th>Price</th>
                			 				<th>Category</th>
                			 			</tr>
                                    </thead>
                                    <tbody id="loadProductList">
                                        
                                    </tbody>
            			 		</table>
            			 	</div>
            			 </div>
            		</div>
            	</div>
            	 
        	</div>
    </div>
</div>
</div>

