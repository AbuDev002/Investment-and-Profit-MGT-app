<!-- Modal -->
<div class="modal add-contribute-modal animate__animated animate__zoomIn" id="contributionModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">ADD NEW CONTRIBUTION</h5>
                <button type="button" id="addNewContribution" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               <!--  <center><h5 class="card-title">MEMBER'S INFORMATION</h5></center> -->
        <form method="post" id="ContributionForm">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="card">
                         <div class="card-body">
                           <label>Name of Member</label>
                      <div class="form-group"> 
                        <select id="selectpicker" class="form-control selectpicker" name="member_id" data-live-search="true" style="background: #fff;">
                           
                           <option value="">Choose Member</option>
                           <?php 
                              include_once('connection.php');
                              $getstafflist = mysqli_query($connect,"select * from members");
                              while($memberlist = mysqli_fetch_array($getstafflist)){
                              ?>
                                 <option value="<?php echo $memberlist['id'];?>"><?php echo $memberlist['firstname']." ".$memberlist['surname']." ".$memberlist['othername'];?></option>
                              <?php
                              }
                           ?>
                        </select>
                      </div>
                    
                      <label> Amount Contributed </label>
                      <div class="form-group"> 
                        <input type="text" name="amount" id="amount" class="form-control" placeholder="Enter amount..." autocomplete="off">
                        <!--validation here-->
                        
                      </div>
    
                      <div class="form-group">
                        <label for="exampleFormControlSelect1"> Date of Contribution </label>
                        <input type= "month" name="date_deposit" id="date_deposit" class="form-control"> 
                      </div>
                      <div class="form-group">
                        <input type="submit" value="Save Contribution" name="btnContribution" id="btnContribution" class="btn btn-primary btn-block">
                      </div>
                         </div>
                      </div>
                     
                    </div>
                    <div class="col-md-6" style="background: url('images/img-contribute.jpg') no-repeat;background-size:contain;"></div>
                </div>   
               
            </div>
            <div class="modal-footer">
                <center><small>Copyright &copy; <?php echo date('Y');?> All rights reserved <strong>ICT/MIS Unit</strong></small></center>
               
            </div>
        </form>
        </div>
    </div>
</div>
