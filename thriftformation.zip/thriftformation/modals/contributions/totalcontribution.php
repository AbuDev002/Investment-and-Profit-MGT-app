<!-- Modal -->
<div class="modal total-contribute-modal animate__animated animate__zoomIn" id="TotalcontributionModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">TOTAL CONTRIBUTIONS</h5>
                <button type="button" id="TotalContribution" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
       			 
                  <div class="row">
                    <div class="col-md-12">
                      <div class="card">
                         <div class="card-body">
                           <h4>Track Contributions</h4>
                           <p><div id="error"></div></p>
					        <form id="check-contribution" method="post">
					        	<div class="row">
					        		<div class="col-md-6">
					        			<div class="form-group">
					        				<label>From:</label>
					        				<input name="from" id="from" type="month"  class="form-control tcal" value="<?php if(isset($_POST['from'])){ echo $_POST['from'];}?>"  autocomplete="off"/>
					        			</div>
					        		</div>
					        		<div class="col-md-6">
					        			<label>To:</label>
					        			<input name="to" id="to" type="month" value="<?php if(isset($_POST['to'])){ echo $_POST['to'];}?>"  autocomplete="off"  class="form-control tcal" />
					        		</div>
					        	</div>
					        	<br>
					        	<div class="form-group">
					        		<button type="submit" name="btnSearch" id="working" class="btn btn-primary btn-block btnCalculate">Track Contributions</button>
					        	</div>
					    
                        </form>
                        <br />
                        <hr>
					   <b>Total Contributions:</b>
					  <!--  <p class="displayTotal"></p>  -->
             <input type="text" class="form-control displayTotal" size="40" name="displayTotal" disabled="disabled"> 
					   
					   </div>
					   </div>
                    </div>
                    
                </div>   
            </div>
            <div class="modal-footer">
                <center><small>Copyright &copy; <?php echo date('Y');?> All rights reserved <strong>ICT/MIS Unit</strong></small></center>
               
            </div>
        
        </div>
    </div>
</div>
