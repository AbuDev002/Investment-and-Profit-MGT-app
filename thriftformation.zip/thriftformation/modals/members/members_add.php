<!-- Modal -->
<div class="modal new-member-modal animate__animated animate__zoomIn" id="membersModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">MEMBERSHIP REGISTRATION FORM</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               <!--  <center><h5 class="card-title">APPLICANT DETAILS</h5></center> -->
               
        <form method="post" id="addmember_form">
                  <div class="card">
                    <div class="card-body">
                        <div class="row">
                    <div class="col-md-6">
                       <label> Staff ID</label>
                      <div class="form-group">
                          <input type="text" name="staffno" id="staffno" class="form-control" placeholder="PFN Number" />
                      </div>
                       <label> Firstname </label>
                      <div class="form-group">
                          <input type="text" name="firstname" id="firstname" class="form-control" placeholder="Firstname..." />
                      </div>
                       <label> Surname </label>
                      <div class="form-group">
                          <input type="text" name="surname" id="surname" class="form-control" placeholder="Surname..." />
                      </div>
                       <label> othername </label>
                      <div class="form-group">
                          <input type="text" name="othername" id="othername" class="form-control" placeholder="Othername..." />
                      </div>
                       <div class="form-group">
                          <label class="my-1 mr-2"  for="gender">Gender</label>
                          <select class="custom-select my-1 mr-sm-2" name="gender" id="gender">
                              <option selected>--Select--</option>
                              <option value="Male">Male</option>
                              <option value="Female">Female</option>
                          </select>
                      </div>

                       <div class="form-group">
                          <label class="my-1 mr-2" for="marital_status">Marital Status</label>
                          <select class="custom-select my-1 mr-sm-2" name="marital_status" id="marital_status">
                              <option selected>--Select--</option>
                              <option value="Single">Single</option>
                              <option value="Married">Married</option>
                              <option value="Divorce">Divorce</option>
                              <option value="Widow">Widow</option>
                          </select>
                      </div>
                       
                    </div>
                    <div class="col-md-6">
                      <label>Phone Number</label>
                      <div class="form-group">
                          <input type="text" class="form-control" name="phoneno" id="phoneno" placeholder="Phone Number" />
                      </div>
                      <div class="form-group">
                          <label for="address">Address</label>
                          <textarea class="form-control" name="address" id="address" rows="3"></textarea>
                      </div>
                      <center>NEXT OF KIN</center>
                       <label> Full Name</label>
                        <div class="form-group">
                            <input type="text" name="nok_name" class="form-control" placeholder="Next of kin name.." />
                        </div>
                         <div class="form-group">
                            <label for="nok_relationship">Next of Kin Relationship</label>
                            <select class="form-control" name="nok_relationship" id="nok_relationship">
                                <option selected>--Select--</option>
                                <option value="Father">Father</option>
                                <option value="Mother">Mother</option>
                                <option value="Brother">Brother</option>
                                <option value="Sister">Sister</option>
                                <option value="Cousin">Cousin</option>
                                <option value="Napew">Napew</option>
                                <option value="Naighbour">Naighbour</option>
                                <option value="Son">Son</option>
                                <option value="Daughter">Daughter</option>
                                <option value="Step Mother">Step Mother</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="nok_address">Next of Kin Address</label>
                            <textarea class="form-control" name="nok_address" id="nok_address" rows="3" placeholder="Enter Address..."></textarea>
                        </div>

                    </div>
                </div> 
                    </div>
                  </div>
                    
               
            </div>
            <div class="modal-footer">
                <input type="hidden" name="member_id" id="member_id" /> 
                <!-- <button type="button"  class="btn btn-secondary" data-dismiss="modal">Exit</button> -->
                <!-- data-dismiss="modal" -->
                <input type="submit" value="Save Member" name="btnAddMember" id="btnAddMember" class="btn btn-primary btn-block">
            </div>
        </form>
        </div>
    </div>
</div>
