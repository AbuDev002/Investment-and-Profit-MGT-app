<div id="dataModal" class="modal fade animate__animated animate__zoomIn">  
      <div class="modal-dialog modal-xl">  
           <div class="modal-content">  
                <div class="modal-header">
                <h5 class="modal-title">Personal Details and Loan History</h5>    
                     <button type="button" class="close" data-dismiss="modal">&times;</button>  
                     
                </div>  
                <div class="modal-body"> 
                  <div class="card">
                     <div class="card-body">
                        <div class="row">
                            <div class="col-md-6" id="member_detail">
                              
                            </div>
                            <div class="col-md-6">
                                <h5>Loan History</h5>
                                <hr>
                            </div>
                        </div>
                     </div>
                  </div> 
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div>  
           </div>  
      </div>  
 </div>  