<!-- Modal -->
<div class="modal apply-loan-modal animate__animated animate__zoomIn" id="ApplyLoanModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">LOAN APPLICATION FORM</h5>
                <button type="button" id="applyLoan" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               <!--  <center><h5 class="card-title">MEMBER'S INFORMATION</h5></center> -->
        <form name="loandata" id="loandata">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="card">
                         <div class="card-body">
                           <label>Name of Member</label>
                      <div class="form-group"> 
                        <select id="selectpicker" class="form-control selectpicker" name="staff_id" data-live-search="true" style="background: #fff;">
                           
                           <option value="">Choose Member</option>
                           <?php 
                              include_once('connection.php');
                              $getstafflist = mysqli_query($connect,"select * from members");
                              while($memberlist = mysqli_fetch_array($getstafflist)){
                              ?>
                                 <option value="<?php echo $memberlist['id'];?>"><?php echo $memberlist['firstname']." ".$memberlist['surname']." ".$memberlist['othername'];?></option>
                              <?php
                              }
                           ?>
                        </select>
                      </div>
                    
                      <label> Loan Amount </label>
                      <div class="form-group"> 
                        <input type="text" name="loan_amount" id="loan_amount" class="form-control" placeholder="Enter amount..." oninput="calculate();" autocomplete="off">
                        <!--validation here-->
                        
                      </div>
    
                      <div class="form-group">
                        <label for="exampleFormControlSelect1"> Date Issued </label>
                        <input type= "date" name="loan_request_date" id="loan_request_date" class="form-control"> 
                      </div>

                      <div class="form-group">
                        <label for="exampleFormControlSelect1">Loan Period (1 Month) </label>
                        <input type= "text" name="months" id="months" readonly="readonly" value="1" class="form-control" oninput="calculate();"> 
                      </div>
                      <div class="form-group">
                        <input type="submit" value="Save Loan Aplication" name="btnLoan" id="btnLoan" class="btn btn-primary btn-block">
                      </div>
                         </div>
                      </div>
                     
                    </div>
                    <div class="col-md-6" >
                      <div class="card">
                         <div class="card-body">
                             <label> Interest (%) </label>
                      <div class="form-group"> 
                        <input type="text" name="interest" oninput="calculate();" id="interest" class="form-control" placeholder="Enter Interest..." autocomplete="off">
                        <!--validation here-->
                        
                      </div>

                       
                      <p><strong>Payment Information</strong></p>
                      <hr>
                     <!--  <p><strong>Monthly Payment:</strong> <input type="text" name="monthly_payment" class="form-control" size="12"></p> -->
                      <p><strong>Expected amount to be paid:</strong> <input type="text" name="paytotal" class="form-control" size="12" autocomplete="off" readonly></p>
                      <p><strong>Loan Interest:</strong> <input type="text" name="totalinterest" class="form-control" size="12" autocomplete="off" readonly></p>
                         </div>
                      </div>
                    </div>
                </div>   
               
            </div>
            <div class="modal-footer">
              <input type="hidden" name="member_id" id="member_id" />
                <center><small>Copyright &copy; <?php echo date('Y');?> All rights reserved <strong>BSHK Cooperative Society</strong></small></center>
               
            </div>
        </form>
        </div>
    </div>
</div>
<script type="text/javascript">
function calculate() {
    // Get the user's input from the form. Assume it is all valid.
    // Convert interest from a percentage to a decimal, and convert from
    // an annual rate to a monthly rate. Convert payment period in years
    // to the number of monthly payments.
    var principal = document.loandata.loan_amount.value;
    var interest = document.loandata.interest.value / 100 * (principal);
    var payments = document.loandata.months.value * 1;
    // Check that the result is a finite number. If so, display the results.
    if (!isNaN(interest) && 
        (interest != Number.POSITIVE_INFINITY) &&
        (interest != Number.NEGATIVE_INFINITY)) {

        //document.loandata.monthly_payment.value = round(monthly);
        document.loandata.paytotal.value = Number(principal) + Number(interest);
        document.loandata.totalinterest.value = interest;
    }
    else {
        document.loandata.paytotal.value = "";
        document.loandata.totalinterest.value = "";
    }
}

// This simple method rounds a number to two decimal places.
// function round(x) {
//   return Math.round(x*100)/100;
// }
</script>
