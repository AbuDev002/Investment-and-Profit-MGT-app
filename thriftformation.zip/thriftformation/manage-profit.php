<?php
  session_start();
  if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
      header('location:index.php');
  }
?>
<!doctype html>
<html lang="en">
<?php include_once ('template/head.php')?>

<body>
	<?php include_once('template/header.php');?>
<div class="container">
<br/>
	<div class="container" style="padding: 0px;">
		<div class="row">
			<div class="col-md-9" style="min-height:520px;">
        <div class="card shadow p-3 mb-5 bg-white rounded"">
          <div class="card-header"><strong>MONTHLY CONTRIBUTIONS AND PROFIT SHARING</strong></div>
          <div class="card-body">
           
            <form id="profitSharingForm" method="get" action="profit_share_report.php">
            <div class="form-row">
              <div class="col-md-3">
                <label><strong>CONTRIBUTIONS</strong></label>
                <input type="text" class="form-control" name="monthlyContributiontotal" id="monthlyContributiontotal" value=""  placeholder="Monthly Contributions..." readonly="readonly">
                <small id="spinload"></small>
              </div>
              <div class="col-md-3">
                 <label><strong>SELECT DATE</strong></label>
                <input type="month" name="contribution_date" value="<?php echo date('Y-m'); ?>" class='form-control date' id="datepicker" placeholder="" onchange="getTotalContribution();">
              </div>
              <div class="col-md-3 shareprofit animate__animated animate__zoomIn" style="display:none">
                <label><strong>PROFIT OBTAINED</strong></label>
                <input type="text"  class="form-control" id="profit_obtained" name="profit_obtained" value="" placeholder="Enter profit..." autocomplete="off">
              </div>
              <div class="col-md-3 shareprofit animate__animated animate__zoomIn" style="display:none">
                <br>
                <button type="button" class="nav-link active btn btn-primary btn-sm btn-block" id="btnShareprofit" style="margin-top:6px;">Share Profit</button>
              </div>
            </div>
             
            <!-- <div class="shadow-none table-responsive"> -->
              
          </div>

        </div>
         <p><button class="btn btn-primary btn-block animate__animated animate__zoomIn" id="report_button" name="btnGetSharedProfitReport" style="display: none;">Print as report <i class="fa fa-file"></i></button></p>
         </form>
				<div class="card" style="min-height: 500px; margin: 0px;">
					<div class="card-header" style="background: #F0F0F0;">
						<center><h5 class="card-title">LIST OF CONTRIBUTORS AND PROFIT ENTITLED </h5></center>
					</div>
						<div class="card-body">
						
									<hr>
                  <!-- dt-responsive nowrap -->
                 <!--  <form> -->
                  <table class="table table-striped table-bordered table-responsive  contribution_table" id="contribution_table" style="width:100%;">
                        <thead>
                          <tr>
                            <th>S/N</th>
                            <th>Name of Member</th>
                            <th>Amount Contributed</th>
                            <th>Percentage (%)</th>
                            <th>Profit Entitled </th>
                            <!-- <th><button id="checkall">Check All</button></th> -->
                          </tr>
                          
                        </thead>
                        <tbody id="displaybeneficiarieslist">

                        </tbody>
                      </table>
									<!-- 	</form> -->
									<!-- </div> -->
									
								
						</div>
				
				</div>
			</div>
				<?php include_once('template/menu.php');?>
		</div>
	</div>
 <!--</div>-->
 
  
</div>
<!-- </form> -->

<!--</div>-->

<?php include_once('template/footer.php');?>
<?php include_once('modals/contributions/member_contribute.php')?>
<?php include_once('modals/contributions/totalcontribution.php')?>
<?php include_once('scripts/javascript.php')?>
<script type="text/javascript">
    var formValues = JSON.parse(localStorage.getItem('formValues')) || {};
    var $checkboxes = $("#displaybeneficiarieslist :checkbox");
    var $button = $("#checkall");

    function allChecked(){
      return $checkboxes.length === $checkboxes.filter(":checked").length;
    }

    function updateButtonStatus(){
      $button.text(allChecked()? "Uncheck all" : "Check all");
    }

    function handleButtonClick(){
      $checkboxes.prop("checked", allChecked()? false : true)
    }

    function updateStorage(){
      $checkboxes.each(function(){
        formValues[this.id] = this.checked;
      });

      formValues["buttonText"] = $button.text();
      localStorage.setItem("formValues", JSON.stringify(formValues));
    }

    $button.on("click", function() {
      handleButtonClick();
      updateButtonStatus();
      updateStorage();
    });

    $checkboxes.on("change", function(){
      updateButtonStatus();
      updateStorage();
    });

    // On page load
    $.each(formValues, function(key, value) {
      $("#" + key).prop('checked', value);
    });

    $button.text(formValues["buttonText"]);
    </script>
<script src="js/bootstrap-select.min.js"></script>
<script type="text/javascript">
   function getTotalContribution() {  
        var date_deposit = $("#datepicker").val();
           $.ajax({  
                url:"app/investments/totalAmountContributed.php",  
                method:"POST",  
                data:{date_deposit:date_deposit},  
                dataType:"json",
                  beforeSend: function()
                    {
                        $("#spinload").html('<span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span> Calculating...');
                    },  
                success:function(data){
                   
                   if(data.monthTotal == null){ 
                    setTimeout(function () {
                     $(".shareprofit").css("display","none");
                     $("#report_button").css("display","none");
                     $('#monthlyContributiontotal').val(0);
                     $("#spinload").html('<p class="text-danger">No contribution.</p>');
                     },2000);
                    
                   }else{
                    setTimeout(function () {
                    $('#monthlyContributiontotal').val(data.monthTotal);
                    $("#spinload").html('<p class="text-success">Contributed: &#8358; '+data.monthTotal+'</p>');
                    $(".shareprofit").css("display","block");
                    $("#report_button").css("display","block");
                    //$("#profit_obtained").val(4050);
                     },2000); 
                     
                   }
                }
           });  
 }
  </script>
  <script type="text/javascript">
   //this function is usded in getting list of loan application
   function loadBeneficiaryList() {
    setInterval(function(){
        var xhttp = new XMLHttpRequest();
        var contdate = document.getElementById("datepicker").value;
        var monthCont = document.getElementById("monthlyContributiontotal").value;
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
           document.getElementById("displaybeneficiarieslist").innerHTML = this.responseText;
          }
        };
        xhttp.open("POST", "fetchbeneficiarylist.php?q="+contdate+"&mc="+monthCont, true);
        xhttp.send();
      },2000);
    }
    loadBeneficiaryList();
</script>
<script type="text/javascript">
document.getElementById('select-all').onclick = function() {
  var checkboxes = document.getElementsByName('single_select');
  for (var checkbox of checkboxes) {
    checkbox.checked = this.checked;
  }
}
</script>
 <script>
    $(document).on("click", "#btnShareprofit", function () {
        //get value of message 
        var members_contribution = $("#monthlyContributiontotal").val();
        var contribution_month = $("#datepicker").val();
        var profit_obtained = $("#profit_obtained").val();
        //check if value is not empty
        if(members_contribution == "")  
           {  
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Enter total contribution');
           } 
           else if(contribution_month == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Enter month'); 
           } 
           else if(profit_obtained == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Enter profit amount...'); 
           } 
           else 
           {
              //Ajax call to send data to the insertprofit.php
              $.ajax({
                  type: "POST",
                  url: "app/profit/insertprofit.php",
                  data: {members_contribution: members_contribution,contribution_month: contribution_month,profit_obtained: profit_obtained},
                  cache: false,
                  success: function (data) {
                      if(data =="ok"){
                        alertify.set('notifier','position', 'top-center');
                        alertify.success('Profit shared successfully...'); 
                      }else{
                        alertify.set('notifier','position', 'top-right');
                        alertify.error('An error occured...'); 
                      }
                  }
              });
            }
        });
    //$('#contribution_table').DataTable();
    // $('#contribution_table').DataTable( {
    //     dom: 'Bfrtip',
    //     buttons: [
    //         'print'
    //     ]
    // } );
</script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#contribution_table').DataTable( {
        //dom: 'Bfrtip',
        // buttons: [
        //     {
        //         extend: 'print',
        //         text:'',
        //         className: 'btn btn-primary btn-sm fa fa-print',
        //         customize: function ( win ) {
        //             $(win.document.body)
        //                 .css( 'font-size', '10pt' )
                        
        //             $(win.document.body).find( 'table' )
        //                 .addClass( 'compact' )
        //                 .css( 'font-size', 'inherit' );
        //         }
        //     }
        // ]
    } );
} );
</script>
<script type="text/javascript">
  //$('#report_button').click( alert("i listented "));
</script>
</body>
</html>