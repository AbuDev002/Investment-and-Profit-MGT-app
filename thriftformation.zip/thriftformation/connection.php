<?php 
	$connect=mysqli_connect('localhost','root','','thriftapp');
		if(!$connect){
			echo "there is error with database connection. Please verify";
		}
			
?>