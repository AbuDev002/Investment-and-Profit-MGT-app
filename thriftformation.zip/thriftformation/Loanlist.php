
<?php
include_once('connection.php');
$sn = 0;
$query="SELECT * FROM loan WHERE exp_amt > 0 ORDER BY id DESC";
$result=mysqli_query($connect,$query);
if(mysqli_num_rows($result) >0){

while($row=mysqli_fetch_array($result)){
   $sn++;
?>
<tr>
  <td><?php echo $sn;?></td>
    <td>
      <?php 
          
      $getmember = mysqli_query($connect,"select * from members where id=".$row['member_id']."");
       $getmember_name = mysqli_fetch_array($getmember);
      echo $getmember_name['surname']." ".$getmember_name['firstname']." ".$getmember_name['othername'];
      ?>
      
    </td>
  <td><?php echo $row['amt'];?></td>
  <td><?php echo $row['date_collected'];?></td>
  <td><?php echo $row['exp_amt'];?></td>
  <td><button type="button" class="btn btn-info btn-sm pay_myloan" id="<?php echo $row["id"];?>" data-toggle="modal" data-target="#PayLoanModal" title="Pay Loan"><i class="fa fa-money"></i></button> &nbsp; | &nbsp; <a href="#" class="btn btn-info btn-sm" title="Print report"><i class="fa fa-print"></i></a></td>
 <!--  <td><button class="btn btn-info"><i class="fa fa-edit"></i></button> | <button class="btn btn-danger"><i class="fa fa-trash"></i></button></td> -->
</tr>
<?php } }else{ ?>
  <tr>
    <td align="center" colspan="10"><span>No loan application available.</span></td>
  </tr>
<?php } ?>


