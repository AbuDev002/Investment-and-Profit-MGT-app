<?php
session_start();
if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
header('location:index.php');
}
?>
<!doctype html>
<html lang="en">
<?php include_once ('template/head.php')?>
<body>
<?php include_once('template/header.php');?>
<br/>
<div class="container">
<div class="row">
<div class="col-md-9">
	<div class="btn-group" role="group" aria-label="Basic example" style="margin-bottom: 10px;">
		<button class="btn btn-primary" data-toggle="modal" data-target="#AddCategoryModal"><i class="fa fa-plus"></i> Add Category</button>&nbsp;&nbsp;
	  <button class="btn btn-primary" data-toggle="modal" data-target="#AddProductModal"><i class="fa fa-plus"></i> Add Product</button>&nbsp;&nbsp;
	  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#RequestCommodityModal">Apply Commodity Loan</button>
	  
	</div>
<div class="card">
	<div class="card-header">
		<center><h5>LIST OF MEMBERS WITH COMMODITY LOAN</h5></center>
	</div>
<div class="card-body">
	<table class="table table-bordered table-striped" id="tbl_commodities" style="font-size:14px;">
			<thead>
			<tr>
				<th>ID</th>
				<th style="width:150px;">Name</th>
				<th>Product Name</th>
				<th>Product Price</th>
				<th>Date Recieved</th>
				<th>Admin Charges</th>
				<th></th>
				<th></th>
			</tr>
			</thead>
			<tbody id="loadcommodityloans">
				
			</tbody>
	</table>
	
</div>
</div>
</div>
<?php include_once('template/menu.php');?>
</div>	
</div>
<!--</div>-->

<?php include_once('template/footer.php');?>
<?php include_once('modals/commodities/add_new_commodity.php')?>
<?php include_once('modals/commodities/request_commodity_loan.php')?>
<?php include_once('modals/commodities/pay_commodity_loan.php')?>
<?php include_once('modals/commodities/add_category.php')?>
<?php include_once('scripts/javascript.php')?>
<script src="js/bootstrap-select.min.js"></script>
<script type="text/javascript">
	$('#addCategoryForm').on("submit", function(event){  
           event.preventDefault();  
           if($('#category_name').val() == "")  
           {  
               
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Enter category name');
           } 
           else  
           {  
                $.ajax({  
                     url:"app/commodities/add_category.php",  
                     method:"POST",  
                     data:$('#addCategoryForm').serialize(),  
                     beforeSend:function(){  
                          $('#btnAddCategory').val("Saving...");  
                     },  
                     success:function(data){ 
                     	  alertify.set('notifier','position', 'top-right');
                 		  alertify.success('Category added successfully'); 
                          $('#addCategoryForm')[0].reset();
                          $('#btnAddCategory').val("Add");  
                          //$('#ApplyLoanModal').modal('hide');  
                          //$('#member_table').html(data);  
                     }  
                });  
           }  
      });

	$('#addCommodityForm').on("submit", function(event){  
           event.preventDefault();  
           if($('#product_name').val() == "")  
           {  
               
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Enter product name');
           } 
            else if($('#product_price').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Enter product price'); 
           }
            else if($('#product_category').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Enter product category'); 
           }  
           else  
           {  
                $.ajax({  
                     url:"app/commodities/add_product.php",  
                     method:"POST",  
                     data:$('#addCommodityForm').serialize(),  
                     beforeSend:function(){  
                          $('#btnAddCommodity').val("Saving...");  
                     },  
                     success:function(data){ 
                     	  alertify.set('notifier','position', 'top-right');
                 		  alertify.success('Product added successfully'); 
                          $('#addCommodityForm')[0].reset();
                          $('#btnAddCommodity').val("Add");  
                          //$('#ApplyLoanModal').modal('hide');  
                          //$('#member_table').html(data);  
                     }  
                });  
           }  
      });

	$('#CommodityLoanForm').on("submit", function(event){  
           event.preventDefault();  
           if($('#selectpicker').val() == "")  
           {  
               
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Select member');
           } 
           //  else if($('#product_name').val() == '')
           // {  
           //      alertify.set('notifier','position', 'top-right');
           //       alertify.error('Enter product name'); 
           // }
            else if($('#price').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Enter product price'); 
           } 
            else if($('#date_recieved').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Enter date...'); 
           } 
            else if($('#loan_charges').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Enter loan charges...'); 
           }  
           else  
           {  
                $.ajax({  
                     url:"app/commodities/apply_commodity_loan.php",  
                     method:"POST",  
                     data:$('#CommodityLoanForm').serialize(),  
                     beforeSend:function(){  
                          $('#btnCommodityLoan').val("Saving...");  
                     },  
                     success:function(data){ 
                     	  alertify.set('notifier','position', 'top-right');
                 		  alertify.success('Application successfuly.'); 
                          $('#CommodityLoanForm')[0].reset();
                          $('#btnCommodityLoan').val("Apply Loan");  
                          //$('#ApplyLoanModal').modal('hide');  
                          //$('#member_table').html(data);  
                     }  
                });  
           }  
      });
  $(document).on('click', '.delete_category', function(){  
           var member_id = $(this).attr("id");  
           if(member_id != '')  
           {  
                $.ajax({  
                     url:"app/commodities/delete_category.php",  
                     method:"POST",  
                     data:{member_id:member_id},  
                     success:function(data){  
                          alertify.set('notifier','position', 'top-right');
                          alertify.success('Category deleted'); 
                     }  
                });  
           }            
      });
  //remove product from list
  $(document).on('click', '.delete_product', function(){  
           var member_id = $(this).attr("id");  
           if(member_id != '')  
           {  
                $.ajax({  
                     url:"app/commodities/delete_product.php",  
                     method:"POST",  
                     data:{member_id:member_id},  
                     success:function(data){  
                          alertify.set('notifier','position', 'top-right');
                          alertify.success('Product deleted'); 
                     }  
                });  
           }            
      });
   $(document).on('click', '.payCommodityLoan', function(){  
           var member_id = $(this).attr("id");  
           $.ajax({  
                url:"app/commodities/fetch_commodity_loan_list.php",  
                method:"POST",  
                data:{member_id:member_id},    
                success:function(data){   
                     $('#loadMemgberLoanDetails').html(data);  
                     //$('#member_id').val(data.id);  
                     $('#btnAddMember').val("Update");  
                     $('#PayCommodityLoanModal').modal('show');  
                }  
           });  
      });
    $('#PayCommodityLoanForm').on("submit", function(event){  
           event.preventDefault();  
           if($('#amount_recieved').val() == "")  
           {  
               
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Enter amount recieved');
           } 
           else  
           {  
                $.ajax({  
                     url:"app/commodities/paycommodityloan.php",  
                     method:"POST",   
                     data:{
                        member_name:$('#member_name').val(),
                        remaining_balance:$('#remaining_balance').val()
                      }, 
                      cache: false, 
                     beforeSend:function(){  
                          $('#btnPayCommodityLoan').val("Paying Loan...");  
                     },  
                     success:function(data){  
                          alertify.set('notifier','position', 'top-right');
                          alertify.success('Payment recieved');
                          $('#PayCommodityLoanForm')[0].reset();
                          $('#btnPayCommodityLoan').val("Pay Loan"); 
                     }  
                });  
           }  
      });
      $('#tbl_commodities').DataTable(); 
</script>
<script type="text/javascript">
	 $(".modal").modal({
        show: false,
        backdrop: 'static'
    });  
</script>
<script type="text/javascript">
  $(document).ready(function(){
    $('.selectpicker').selectpicker();
  })
</script>
<script type="text/javascript">
	 //this function is usded in getting list of commodity loan application
   function loadLoanList() {
    setInterval(function(){
           var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
           document.getElementById("loadcommodityloans").innerHTML = this.responseText;
          }
        };
        xhttp.open("GET", "get_commodity_loan_list.php", true);
        xhttp.send();
      },1000);
    }
    loadLoanList();
   //this function is usded in getting list product Category
   function loadProductCategoryList() {
    setInterval(function(){
           var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
           document.getElementById("loadProductCategory").innerHTML = this.responseText;
          }
        };
        xhttp.open("GET", "app/commodities/get_product_category_list.php", true);
        xhttp.send();
      },1000);
    }
    loadProductCategoryList();
    //this function is usded in getting product list
   function loadProductList() {
    setInterval(function(){
           var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
           document.getElementById("loadProductList").innerHTML = this.responseText;
          }
        };
        xhttp.open("GET", "app/commodities/get_product_list.php", true);
        xhttp.send();
      },1000);
    }
    loadProductList();

     //this function is usded in getting product list
   // function loadMemgberLoanDetails() {
   //  setInterval(function(){
   //         var xhttp = new XMLHttpRequest();
   //          //var member_id = $(".payCommodityLoan").attr("id");
   //          var member_id = document.getElementById("member_id").value;
   //      xhttp.onreadystatechange = function() {
   //        if (this.readyState == 4 && this.status == 200) {
   //         document.getElementById("loadMemgberLoanDetails").innerHTML = this.responseText;
   //        }
   //      };
   //      xhttp.open("GET", "app/commodities/fetch_commodity_loan_list.php?mid="+member_id, true);
   //      xhttp.send();
   //    },1000);
   //  }
   //  loadMemgberLoanDetails();
</script>
</body>
</html>