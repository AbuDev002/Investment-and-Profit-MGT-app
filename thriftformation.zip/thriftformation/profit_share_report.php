<?php
        //session_start();
		ob_start();
		//error_reporting(1);
		require_once 'dompdf/autoload.inc.php';
		
?>
<?php include_once('connection.php');?>

<!Doctype html>
<html>
	<head>
		<title>Report of profit shared</title>
		
		<style type="text/css">
			#container{
				width:700px;
				height:auto;
				margin:0px auto;
				margin-top:20px;
				text-indent:5px;
                               
			}
				
			th#mdb{
				background-image:url("images/sch-logo.png") no-repeat;
				background-size:contain;
			}
			
			#report_details td{
				border:1px solid black;
				border-collapse:collapse;
			}
			


			.head{
				background:#91C5D4;
				}
		@page { margin: 180px 50px; }
			#header { position: fixed; left: -45px; top: -180px; right: -45px; height: 120px; background-color: #f5f5f5; text-align: center; width:100%; }
			#footer { position: fixed; left: -45px; bottom: -180px; right: -45px; height: 100px; background-color: #f5f5f5; }
			#footer .page:after { content: counter(page, upper-roman); }
			
			/*table#report_details{page-break-inside:avoid}*/
		  .paragraph{
		  	text-align: justify;
		  	line-height: 30px;
		  }
		</style>
	</head>
	
<body>
<div id="container">

<div id="header">
		<table align="center"  width="100%" style="font-size:12px; border-collapse:collapse;">
			<tr>
				<td colspan="3" align="center"><img src="images/hadakai.png" width="50" height="50" style="margin-top: 10px;"></i></h3></td>
			</tr>
			<tr>
				<td colspan="3" align="center"><h2>BSHK COOPERATIVE SOCIETY</h2></td>
			</tr>
			
			<tr>
				<td></td>
				<td align="center"><br/><h2 style="padding:0px; background:#29166F; color:#fff;">LIST OF BENEFICIARIES</h2></td>
				<td></td>
			</tr>
			
		</table>
		
</div>
	<div id="footer">
	<table width="50%" align="center">
		<tr>
			<td width="400"><b>MANAGER' SIGN/Stamp_______________________________</b></td>

		</tr>
	</table>
	<hr/>
	<br>
	<?php echo date('F j, Y');?>
	</div>
<table class="profit_list" width="100%" border="1" id="report_details" cellspacing="0">
 <thead>
  <tr>
    <th>S/N</th>
    <th>Name of Member</th>
    <th>Amount Contributed</th>
    <th>Percentage (%)</th>
    <th>Profit Entitled </th>
    <!-- <th><button id="checkall">Check All</button></th> -->
  </tr>
</thead>
<?php
function formatMoney($number, $fractional=false) {
    if ($fractional) {
        $number = sprintf('%.2f', $number);
    }
    while (true) {
        $replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
        if ($replaced != $number) {
            $number = $replaced;
        } else {
            break;
        }
    }
    return $number;
}
//this function get you the percentage of a number
function get_percentage($total, $number)
{
  if ( $total > 0 ) {
   return round($number / ($total / 100),2);
    //$member_percentage = $number / ($total / 100);
    //return $member_percentage;
  } else {
    return 0;
  }
}
?>
<?php
$i = 0; 
include_once('connection.php'); 
//if(!isset($_GET['q'])){
$query = "SELECT * FROM deposit WHERE date_deposit='".$_GET['contribution_date']."' ORDER BY id DESC";  
$result = mysqli_query($connect, $query);
if($rs = mysqli_num_rows($result) >0){  
while($row = mysqli_fetch_array($result))  
{  
$i++;
?> 

<body>
<tr>  
    <td align="center"><?php echo $i;?></td>  
    <td align="center">
      <?php 
      $getusername = mysqli_query($connect,"select * from members where id='".$row["users_id"]."'");
        $name = mysqli_fetch_array($getusername);
        echo $name['surname']." ".$name['firstname']." ".$name['othername'];
      ?>
      <input type="hidden" name="mem_name" value="<?php echo $name['surname']." ".$name['firstname']." ".$name['othername'];?>">
    </td>  
    <td align="center">
      <?php echo "N ".formatMoney($row["amount"], true);?>
        <input type="hidden" name="amt_cont" value="<?php echo formatMoney($row["amount"], true);?>">
      </td>  
    <td align="center">
      <?php echo get_percentage(@$_GET['monthlyContributiontotal'], $row["amount"]);?>
      <input type="hidden" name="percent_value" id="percent_value" class="percent_value" value="<?php echo get_percentage(@$_GET['monthlyContributiontotal'], $row["amount"]);?>">
      <!-- <input type="hidden" name="" value=""> -->
    </td>
    <td align="center" id="profit_entitled" class="profit_entitled">
       <?php
        $getprofit = mysqli_query($connect,"select * from profit where profit_month='".$_GET['contribution_date']."' and members_contrubution_amount ='".$_GET['monthlyContributiontotal']."'");
          if($presult = @mysqli_num_rows($getprofit) > 0){
          $getprofresult = mysqli_fetch_array($getprofit);
          echo "N ".formatMoney(($getprofresult['profit_amount'] * get_percentage(@$_GET['monthlyContributiontotal'], $row["amount"])) / 100);
        }else{
           echo "0";
        }
       ?> 
       <input type="hidden" name="p_ent" value="<?php echo formatMoney(($getprofresult['profit_amount'] * get_percentage(@$_GET['monthlyContributiontotal'], $row["amount"])) / 100);?>">
    </td>
</tr>
<?php }?>
<tr>
  <td colspan="5" align="right"><strong>Profit Obtained:</strong> N<?php if(isset($getprofresult['profit_amount'])){ echo formatMoney($getprofresult['profit_amount']);
    //json_encode(['profit_obtained' => $getprofresult['profit_amount']]);
}else{ echo "0";}?> 
<input type="hidden" name="p_amt" value="<?php echo $getprofresult['profit_amount']?>">
</td>
</tr> 
<?php 
}else{ echo "<td colspan='6' align='center'><p>No contribution available</p></td>";}?> 
</body>
</table>
		</div>

	</body>
</html>
<?php		
	$html = ob_get_clean();
	use Dompdf\Dompdf;
	use Dompdf\Options;
	require_once 'dompdf/autoload.inc.php';
	$options = new Options();
    $options->set('isRemoteEnabled', TRUE);
    $options->set('debugKeepTemp', TRUE);
    $options->set('isHtml5ParserEnabled', true);
	$dompdf = new DOMPDF($options);
	$contxt = stream_context_create([ 
    'ssl' => [ 
        'verify_peer' => FALSE, 
        'verify_peer_name' => FALSE,
        'allow_self_signed'=> TRUE
    ] 
]);
$dompdf->setHttpContext($contxt);
	$dompdf->set_paper("A4","Portrait");
	$dompdf->load_html($html);
	$dompdf->render();
	$dompdf->stream('profit_shared_report.pdf');
?>