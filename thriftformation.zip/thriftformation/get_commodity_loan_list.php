
<?php
include_once('connection.php');
$sn = 0;
$query="SELECT * FROM commodities_loan WHERE percent_charges > 0 ORDER BY id DESC";
$result=mysqli_query($connect,$query);
if(mysqli_num_rows($result) >0){

while($row=mysqli_fetch_array($result)){
   $sn++;
?>
<tr>
  <td><?php echo $sn;?></td>
    <td>
      <?php 
          
      $getmember = mysqli_query($connect,"select * from members where id=".$row['member_id']."");
       $getmember_name = mysqli_fetch_array($getmember);
      echo $getmember_name['surname']." ".$getmember_name['firstname']." ".$getmember_name['othername'];
      ?>
      
    </td>
  <td>
    <?php
      $get_product_name = mysqli_query($connect,"select * from products where id='".$row['product_id']."'");
      $productrs = mysqli_fetch_array($get_product_name);
      echo @$productrs['product_name'];
    ?>
  </td>
  <td><?php echo $row['product_price'];?></td>
  <td><?php echo $row['date_recieved'];?></td>
  <td><?php echo $row['percent_charges'];?></td>
  <!-- <td><?php //echo $row['loan_duration'];?></td> -->
  <form>
  <td><button type="button" class="btn btn-info btn-sm payCommodityLoan" id="<?php echo $row["id"]; ?>" data-toggle="modal" data-target="#PayCommodityLoanModal"><i class="fa fa-money" title="Pay loan"></i></button></td>
  <td><a href="#" class="btn btn-info btn-sm" title="Print report"><i class="fa fa-print"></i></a></td>
  </form>
 <!--  <td><button class="btn btn-info"><i class="fa fa-edit"></i></button> | <button class="btn btn-danger"><i class="fa fa-trash"></i></button></td> -->
</tr>
<?php } }else{ ?>
  <tr>
    <td align="center" colspan="10"><span>No commodity loan application available.</span></td>
  </tr>
<?php } ?>


